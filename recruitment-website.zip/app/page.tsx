import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight, Heart, HardHat } from "lucide-react"
import Image from "next/image"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">
              Home
            </Link>
            <Link href="/why-us" className="text-gray-700 hover:text-emerald-600 font-medium">
              Why Us
            </Link>
            <Link href="/jobs" className="text-gray-700 hover:text-emerald-600 font-medium">
              Jobs
            </Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">
              Clients
            </Link>
            <Link href="/candidates" className="text-gray-700 hover:text-emerald-600 font-medium">
              Candidates
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 font-medium">
              Contact
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Button variant="outline" className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              <Link href="/register-job">Post a Job</Link>
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Link href="/jobs">Find Jobs</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-emerald-50 to-teal-50 py-20">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Australia's Premier <span className="text-emerald-600">Healthcare or Construction</span> Recruitment
                  Specialists
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Leading recruitment agency specialising in healthcare professionals or construction workers across
                  Sydney, Melbourne, Brisbane, Perth, Adelaide, and all Australian states. Expert recruiters connecting
                  qualified nurses, allied health professionals, project managers, tradespeople, and construction
                  specialists with top employers nationwide.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-lg px-8 py-3">
                    <Link href="/register-job" className="flex items-center">
                      Hire Healthcare or Construction Staff <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50 text-lg px-8 py-3"
                  >
                    <Link href="/jobs" className="flex items-center">
                      Find Healthcare or Construction Jobs <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="relative">
                <Image
                  src="/placeholder.svg?height=500&width=600"
                  alt="Healthcare and construction recruitment specialists Australia"
                  width={600}
                  height={500}
                  className="rounded-lg shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Your Trusted Healthcare or Construction Recruitment Partner
              </h2>
              <p className="text-gray-600">
                Dedicated to connecting quality professionals with leading employers across Australia
              </p>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-4xl font-bold text-emerald-600 mb-2">8</div>
                <div className="text-gray-600">States & Territories Covered</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-emerald-600 mb-2">2</div>
                <div className="text-gray-600">Industry Specialisations</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-emerald-600 mb-2">24/7</div>
                <div className="text-gray-600">Candidate Support</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-emerald-600 mb-2">100%</div>
                <div className="text-gray-600">Commitment to Quality</div>
              </div>
            </div>
          </div>
        </section>

        {/* Industries Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Specialist Healthcare or Construction Recruitment Services Australia
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                Expert recruitment consultants specialising exclusively in healthcare or construction industries. We
                understand AHPRA requirements, construction safety standards, and the unique challenges of recruiting
                qualified professionals in these critical sectors across Australia.
              </p>
            </div>
            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                      <Heart className="h-6 w-6 text-red-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">Healthcare Recruitment Australia</h3>
                  </div>
                  <p className="text-gray-600 mb-6">
                    Specialist healthcare recruitment agency connecting registered nurses, enrolled nurses, allied
                    health professionals, healthcare managers, and medical specialists with hospitals, aged care
                    facilities, community health centres, and private practices across Australia. AHPRA registration
                    verification and clinical competency assessment included.
                  </p>

                  <div className="space-y-4 mb-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Nursing Recruitment Services</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Registered Nurses (RN) - All Specialties</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Enrolled Nurses (EN) - Acute & Aged Care</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Nurse Practitioners & Clinical Nurse Specialists</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Midwives & Maternal Child Health Nurses</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Mental Health Nurses & Community Nurses</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Theatre Nurses & Critical Care Specialists</span>
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Allied Health Professional Recruitment</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Physiotherapists & Exercise Physiologists</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Occupational Therapists & Speech Pathologists</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Social Workers & Psychologists</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Dietitians & Podiatrists</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Medical Imaging & Laboratory Technicians</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Pharmacy & Healthcare Administration Staff</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-red-50 p-4 rounded-lg mb-6">
                    <h4 className="font-semibold text-red-900 mb-3">Healthcare Recruitment Expertise</h4>
                    <ul className="space-y-2 text-red-800">
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>AHPRA registration verification & compliance</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>Clinical competency assessment & skills matching</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>Healthcare facility cultural fit evaluation</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>Ongoing professional development support</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>Locum & permanent placement services</span>
                      </li>
                    </ul>
                  </div>

                  <Button className="w-full bg-red-600 hover:bg-red-700">
                    <Link href="/clients">Hire Healthcare Professionals Australia</Link>
                  </Button>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mr-4">
                      <HardHat className="h-6 w-6 text-orange-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900">Construction Recruitment Australia</h3>
                  </div>
                  <p className="text-gray-600 mb-6">
                    Leading construction recruitment specialists placing project managers, site supervisors, civil
                    engineers, quantity surveyors, skilled tradespeople, and construction workers with major builders,
                    infrastructure companies, and construction firms across Australia. White card verification and
                    safety compliance checks included.
                  </p>

                  <div className="space-y-4 mb-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Construction Management Recruitment</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Project Managers - Residential & Commercial</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Construction Managers & Site Supervisors</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Contract Administrators & Project Coordinators</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Quantity Surveyors & Estimators</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Safety Officers & WHS Coordinators</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Building Surveyors & Quality Managers</span>
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Engineering & Technical Recruitment</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Civil Engineers & Structural Engineers</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Mechanical Engineers & Electrical Engineers</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Geotechnical Engineers & Environmental Engineers</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Building Services Engineers & Fire Engineers</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>CAD Operators & Design Technicians</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Town Planners & Development Managers</span>
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Skilled Trades Recruitment</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Electricians & Electrical Supervisors</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Plumbers & Mechanical Fitters</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Carpenters, Joiners & Cabinet Makers</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Concreters, Tilers & Bricklayers</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Heavy Equipment Operators & Crane Operators</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2 mt-1">•</span>
                          <span>Scaffolders & Steel Fixers</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-4 rounded-lg mb-6">
                    <h4 className="font-semibold text-orange-900 mb-3">Construction Recruitment Expertise</h4>
                    <ul className="space-y-2 text-orange-800">
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>Trade qualification verification & licensing</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>White card & safety certification checks</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>Project experience matching & skills assessment</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>Construction industry knowledge & networks</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>FIFO & interstate placement services</span>
                      </li>
                    </ul>
                  </div>

                  <Button className="w-full bg-orange-600 hover:bg-orange-700">
                    <Link href="/clients">Hire Construction Professionals Australia</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Locations & Services Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Healthcare or Construction Recruitment Services Across Australia
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                Servicing healthcare facilities or construction companies in Sydney, Melbourne, Brisbane, Perth,
                Adelaide, Canberra, Darwin, Hobart, and regional centres across NSW, VIC, QLD, WA, SA, ACT, NT, and TAS.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8 mb-12">
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Major Cities Coverage</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>Healthcare or Construction Recruitment Sydney</li>
                    <li>Healthcare or Construction Recruitment Melbourne</li>
                    <li>Healthcare or Construction Recruitment Brisbane</li>
                    <li>Healthcare or Construction Recruitment Perth</li>
                    <li>Healthcare or Construction Recruitment Adelaide</li>
                    <li>Healthcare or Construction Recruitment Canberra</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Regional Australia</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>Regional Healthcare Recruitment</li>
                    <li>Regional Construction Recruitment</li>
                    <li>Rural & Remote Placements</li>
                    <li>FIFO Construction Roles</li>
                    <li>Locum Healthcare Services</li>
                    <li>Interstate Relocations</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Specialist Services</h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>Executive Healthcare Recruitment</li>
                    <li>Senior Construction Management</li>
                    <li>Graduate Placement Programmes</li>
                    <li>Contract & Temporary Staffing</li>
                    <li>Workforce Planning Solutions</li>
                    <li>Salary Benchmarking</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-emerald-600">
          <div className="container mx-auto px-4 lg:px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Ready to Partner with Australia's Leading Healthcare or Construction Recruiters?
            </h2>
            <p className="text-xl text-emerald-100 mb-8 max-w-3xl mx-auto">
              Whether you're a healthcare facility needing qualified nurses and allied health professionals, or a
              construction company seeking skilled tradespeople and project managers, The Partnership Group delivers
              exceptional recruitment results across Australia.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                variant="outline"
                className="bg-white text-emerald-600 border-white hover:bg-emerald-50 text-lg px-8 py-3"
              >
                <Link href="/register-job">Post Healthcare or Construction Jobs</Link>
              </Button>
              <Button size="lg" className="bg-emerald-800 hover:bg-emerald-900 text-lg px-8 py-3">
                <Link href="/jobs">Find Healthcare or Construction Careers</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TPG</span>
                </div>
                <span className="font-bold text-xl">The Partnership Group</span>
              </div>
              <p className="text-gray-400">
                Australia's premier recruitment partnership, connecting talent with opportunity across Healthcare or
                Construction.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/why-us" className="hover:text-white">
                    Why Us
                  </Link>
                </li>
                <li>
                  <Link href="/jobs" className="hover:text-white">
                    Current Jobs
                  </Link>
                </li>
                <li>
                  <Link href="/clients" className="hover:text-white">
                    For Clients
                  </Link>
                </li>
                <li>
                  <Link href="/candidates" className="hover:text-white">
                    For Candidates
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Industries</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Healthcare</li>
                <li>Construction</li>
                <li>Allied Health</li>
                <li>Project Management</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="text-gray-400 space-y-2">
                <p>1300 TPG JOBS</p>
                <p>info@partnershipgroup.com.au</p>
                <p>
                  Level 15, 1 Martin Place
                  <br />
                  Sydney NSW 2000
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} The Partnership Group. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
