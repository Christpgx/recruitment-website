import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: {
    default: "The Partnership Group - Healthcare & Construction Recruitment Australia",
    template: "%s | The Partnership Group",
  },
  description:
    "Australia's leading healthcare and construction recruitment specialists. Expert recruiters connecting qualified nurses, allied health professionals, project managers, and skilled tradespeople with top employers across Sydney, Melbourne, Brisbane, Perth, Adelaide and all Australian states.",
  keywords: [
    "healthcare recruitment Australia",
    "construction recruitment Australia",
    "nursing recruitment Sydney Melbourne Brisbane",
    "construction jobs Australia",
    "healthcare jobs Australia",
    "recruitment agency Australia",
    "allied health recruitment",
    "project manager recruitment",
    "skilled trades recruitment",
    "AHPRA registered nurses",
    "construction project managers",
    "healthcare professionals Australia",
    "construction workers Australia",
  ],
  authors: [{ name: "The Partnership Group" }],
  creator: "The Partnership Group",
  publisher: "The Partnership Group",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "en_AU",
    url: "https://partnershipgroup.com.au",
    siteName: "The Partnership Group",
    title: "The Partnership Group - Healthcare & Construction Recruitment Australia",
    description:
      "Australia's leading healthcare and construction recruitment specialists connecting qualified professionals with top employers nationwide.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "The Partnership Group - Healthcare & Construction Recruitment Australia",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "The Partnership Group - Healthcare & Construction Recruitment Australia",
    description: "Australia's leading healthcare and construction recruitment specialists.",
    images: ["/og-image.jpg"],
  },
  verification: {
    google: "your-google-verification-code",
  },
  alternates: {
    canonical: "https://partnershipgroup.com.au",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en-AU">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "The Partnership Group",
              alternateName: "TPG Recruitment",
              url: "https://partnershipgroup.com.au",
              logo: "https://partnershipgroup.com.au/logo.png",
              description: "Australia's leading healthcare and construction recruitment specialists",
              address: {
                "@type": "PostalAddress",
                streetAddress: "Level 15, 1 Martin Place",
                addressLocality: "Sydney",
                addressRegion: "NSW",
                postalCode: "2000",
                addressCountry: "AU",
              },
              contactPoint: {
                "@type": "ContactPoint",
                telephone: "+61-1300-874-5627",
                contactType: "customer service",
                areaServed: "AU",
                availableLanguage: "English",
              },
              sameAs: [
                "https://linkedin.com/company/the-partnership-group",
                "https://facebook.com/thepartnershipgroup",
              ],
              serviceArea: {
                "@type": "Country",
                name: "Australia",
              },
              hasOfferCatalog: {
                "@type": "OfferCatalog",
                name: "Recruitment Services",
                itemListElement: [
                  {
                    "@type": "Offer",
                    itemOffered: {
                      "@type": "Service",
                      name: "Healthcare Recruitment",
                      description:
                        "Specialist recruitment for nurses, allied health professionals, and healthcare managers",
                    },
                  },
                  {
                    "@type": "Offer",
                    itemOffered: {
                      "@type": "Service",
                      name: "Construction Recruitment",
                      description: "Expert recruitment for project managers, engineers, and skilled tradespeople",
                    },
                  },
                ],
              },
            }),
          }}
        />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
