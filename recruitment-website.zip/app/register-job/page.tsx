import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft } from "lucide-react"

export default function RegisterJobPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">Home</Link>
            <Link href="/why-us" className="text-gray-700 hover:text-emerald-600 font-medium">Why Us</Link>
            <Link href="/jobs" className="text-gray-700 hover:text-emerald-600 font-medium">Jobs</Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">Clients</Link>
            <Link href="/candidates" className="text-gray-700 hover:text-emerald-600 font-medium">Candidates</Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 font-medium">Contact</Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 bg-gray-50">
        <div className="container mx-auto px-4 lg:px-6 py-12">
          {/* Back Button */}
          <div className="mb-8">
            <Link href="/clients" className="flex items-center text-emerald-600 hover:text-emerald-700">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Client Information
            </Link>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Form */}
            <div className="lg:col-span-2">
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-3xl text-gray-900">Post a Job Opportunity</CardTitle>
                  <p className="text-gray-600">Tell us about your hiring needs and we'll connect you with the right talent</p>
                </CardHeader>
                <CardContent className="space-y-8">
                  {/* Company Information */}
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">Company Information</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Company Name *</label>
                        <Input placeholder="Your Company Name" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Industry *</label>
                        <select className="w-full border border-gray-300 rounded-md px-3 py-2">
                          <option>Select Industry</option>
                          <option>Healthcare</option>
                          <option>Construction</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Contact Person *</label>
                        <Input placeholder="Your Name" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Job Title</label>
                        <Input placeholder="Your Position" />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                        <Input type="email" placeholder="your.email@company.com" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Phone *</label>
                        <Input type="tel" placeholder="0400 000 000" />
                      </div>
                    </div>
                  </div>

                  {/* Job Details */}
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">Job Details</h3>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Job Title *</label>
                      <Input placeholder="e.g. Registered Nurse - ICU, Project Manager - Construction" />
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Location *</label>
                        <Input placeholder="City, State" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Employment Type *</label>
                        <select className="w-full border border-gray-300 rounded-md px-3 py-2">
                          <option>Select Type</option>
                          <option>Full-time</option>
                          <option>Part-time</option>
                          <option>Contract</option>
                          <option>Casual</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Salary Range</label>
                        <Input placeholder="e.g. $70,000 - $85,000" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                        <Input type="date" />
                      </div>
                    </div>
                    <div className="mt-4">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Job Description *</label>
                      <Textarea 
                        placeholder="Describe the role, key responsibilities, and what you're looking for in a candidate..."
                        className="min-h-[120px]"
                      />
                    </div>
                    <div className="mt-4">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Required Qualifications</label>
                      <Textarea 
                        placeholder="List essential qualifications, certifications, and experience requirements..."
                        className="min-h-[100px]"
                      />
                    </div>
                  </div>

                  {/* Additional Requirements */}
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">Additional Information</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Urgency Level</label>
                        <select className="w-full border border-gray-300 rounded-md px-3 py-2">
                          <option>Standard (2-4 weeks)</option>
                          <option>Urgent (1-2 weeks)</option>
                          <option>Critical (ASAP)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Number of Positions</label>
                        <Input type="number" placeholder="1" min="1" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Special Requirements or Benefits</label>
                        <Textarea 
                          placeholder="Any special requirements, benefits, or additional information about the role..."
                          className="min-h-[80px]"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Preferences */}
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">Recruitment Preferences</h3>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox id="exclusive" />
                        <label htmlFor="exclusive" className="text-sm text-gray-700">\
