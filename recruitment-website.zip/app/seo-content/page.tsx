import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle } from "lucide-react"

export default function SEOContentPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">
              Home
            </Link>
            <Link href="/why-us" className="text-gray-700 hover:text-emerald-600 font-medium">
              Why Us
            </Link>
            <Link href="/jobs" className="text-gray-700 hover:text-emerald-600 font-medium">
              Jobs
            </Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">
              Clients
            </Link>
            <Link href="/candidates" className="text-gray-700 hover:text-emerald-600 font-medium">
              Candidates
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 font-medium">
              Contact
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Button variant="outline" className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              <Link href="/register-job">Post a Job</Link>
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Link href="/register-candidate">Find Jobs</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* SEO Content Hub */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                Healthcare or Construction Recruitment Services Australia
              </h1>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
                The Partnership Group is Australia's leading specialist recruitment agency for healthcare professionals
                and construction workers. We connect qualified nurses, allied health professionals, doctors, project
                managers, engineers, tradespeople, and construction specialists with top employers across Sydney,
                Melbourne, Brisbane, Perth, Adelaide, and all Australian states and territories.
              </p>
            </div>

            {/* Comprehensive Service Descriptions */}
            <div className="space-y-16">
              {/* Healthcare Recruitment Services */}
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
                  Healthcare Recruitment Australia - Connecting Caring Professionals
                </h2>

                <div className="grid lg:grid-cols-2 gap-12 mb-12">
                  <div>
                    <h3 className="text-2xl font-semibold text-gray-900 mb-6">
                      Nursing Recruitment Specialists Australia
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Our healthcare recruitment consultants specialise in placing registered nurses, enrolled nurses,
                      nurse practitioners, and nursing managers across Australia's healthcare system. We understand
                      AHPRA registration requirements, clinical competencies, and the unique demands of different
                      healthcare settings.
                    </p>

                    <div className="space-y-4">
                      <div className="border-l-4 border-red-200 pl-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Registered Nurse Recruitment</h4>
                        <p className="text-gray-600 mb-2">
                          Specialist placement of RNs across all clinical areas including:
                        </p>
                        <ul className="text-gray-600 space-y-1">
                          <li>• ICU & Critical Care Nurses - Sydney, Melbourne, Brisbane</li>
                          <li>• Emergency Department Nurses - Public & Private Hospitals</li>
                          <li>• Theatre & Perioperative Nurses - Day Surgery & Hospitals</li>
                          <li>• Medical & Surgical Ward Nurses - Acute Care Settings</li>
                          <li>• Mental Health Nurses - Inpatient & Community Services</li>
                          <li>• Paediatric & Neonatal Nurses - Children's Hospitals</li>
                          <li>• Aged Care Nurses - Residential & Community Care</li>
                          <li>• Community Health Nurses - Home Care & District Nursing</li>
                        </ul>
                      </div>

                      <div className="border-l-4 border-red-200 pl-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Allied Health Professional Recruitment</h4>
                        <p className="text-gray-600 mb-2">
                          Comprehensive recruitment services for allied health professionals:
                        </p>
                        <ul className="text-gray-600 space-y-1">
                          <li>• Physiotherapists - Private Practice & Hospital Settings</li>
                          <li>• Occupational Therapists - Rehabilitation & Community</li>
                          <li>• Speech Pathologists - Paediatric & Adult Services</li>
                          <li>• Social Workers - Healthcare & Mental Health Settings</li>
                          <li>• Dietitians & Nutritionists - Clinical & Community Roles</li>
                          <li>• Psychologists - Clinical & Counselling Positions</li>
                          <li>• Medical Imaging Technologists - Radiology & Ultrasound</li>
                          <li>• Laboratory Scientists - Pathology & Research</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-2xl font-semibold text-gray-900 mb-6">
                      Healthcare Management & Administration Recruitment
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Executive and management recruitment for healthcare leaders, department managers, and
                      administrative professionals who drive healthcare excellence across Australia's public and private
                      healthcare sectors.
                    </p>

                    <div className="space-y-4">
                      <div className="border-l-4 border-red-200 pl-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Healthcare Executive Recruitment</h4>
                        <ul className="text-gray-600 space-y-1">
                          <li>• Chief Executive Officers - Healthcare Organisations</li>
                          <li>• Directors of Nursing - Hospital & Aged Care</li>
                          <li>• Clinical Directors - Medical Specialties</li>
                          <li>• General Managers - Healthcare Operations</li>
                          <li>• Quality & Risk Managers - Patient Safety</li>
                          <li>• Finance Directors - Healthcare Finance</li>
                        </ul>
                      </div>

                      <div className="border-l-4 border-red-200 pl-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Healthcare Administration Recruitment</h4>
                        <ul className="text-gray-600 space-y-1">
                          <li>• Medical Receptionists - GP Practices & Specialists</li>
                          <li>• Practice Managers - Medical Centres</li>
                          <li>• Health Information Managers - Medical Records</li>
                          <li>• Patient Services Coordinators - Hospital Administration</li>
                          <li>• Healthcare Project Managers - System Implementation</li>
                          <li>• Clinical Governance Officers - Compliance & Quality</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-red-50 p-8 rounded-lg">
                  <h3 className="text-xl font-semibold text-red-900 mb-4">Healthcare Recruitment Across Australia</h3>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <h4 className="font-semibold text-red-800 mb-2">Major Cities</h4>
                      <ul className="text-red-700 space-y-1">
                        <li>• Healthcare Recruitment Sydney NSW</li>
                        <li>• Healthcare Recruitment Melbourne VIC</li>
                        <li>• Healthcare Recruitment Brisbane QLD</li>
                        <li>• Healthcare Recruitment Perth WA</li>
                        <li>• Healthcare Recruitment Adelaide SA</li>
                        <li>• Healthcare Recruitment Canberra ACT</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-red-800 mb-2">Regional Areas</h4>
                      <ul className="text-red-700 space-y-1">
                        <li>• Regional Hospital Recruitment</li>
                        <li>• Rural Healthcare Placements</li>
                        <li>• Remote Area Nursing</li>
                        <li>• Country GP Practice Staff</li>
                        <li>• Regional Allied Health Services</li>
                        <li>• Rural Mental Health Professionals</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-red-800 mb-2">Healthcare Sectors</h4>
                      <ul className="text-red-700 space-y-1">
                        <li>• Public Hospital Systems</li>
                        <li>• Private Healthcare Networks</li>
                        <li>• Aged Care Providers</li>
                        <li>• Community Health Centres</li>
                        <li>• General Practice Networks</li>
                        <li>• Specialist Medical Clinics</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Construction Recruitment Services */}
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
                  Construction Recruitment Australia - Building Exceptional Teams
                </h2>

                <div className="grid lg:grid-cols-2 gap-12 mb-12">
                  <div>
                    <h3 className="text-2xl font-semibold text-gray-900 mb-6">
                      Construction Management & Engineering Recruitment
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Our construction recruitment specialists connect project managers, site managers, engineers, and
                      construction professionals with Australia's leading builders, infrastructure companies, and
                      engineering consultancies. We understand construction industry requirements, safety standards, and
                      project delivery demands.
                    </p>

                    <div className="space-y-4">
                      <div className="border-l-4 border-orange-200 pl-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Project Management Recruitment</h4>
                        <p className="text-gray-600 mb-2">
                          Senior construction management professionals for major projects:
                        </p>
                        <ul className="text-gray-600 space-y-1">
                          <li>• Project Managers - Residential & Commercial Construction</li>
                          <li>• Construction Managers - High-Rise & Infrastructure</li>
                          <li>• Site Managers - Building & Civil Construction</li>
                          <li>• Contract Administrators - Major Projects</li>
                          <li>• Project Directors - Multi-Million Dollar Developments</li>
                          <li>• Development Managers - Property & Infrastructure</li>
                          <li>• Construction Planners - Project Scheduling & Coordination</li>
                          <li>• Quantity Surveyors - Cost Management & Estimation</li>
                        </ul>
                      </div>

                      <div className="border-l-4 border-orange-200 pl-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Engineering Recruitment Services</h4>
                        <p className="text-gray-600 mb-2">Specialist engineering recruitment across all disciplines:</p>
                        <ul className="text-gray-600 space-y-1">
                          <li>• Civil Engineers - Infrastructure & Development</li>
                          <li>• Structural Engineers - Building & Bridge Design</li>
                          <li>• Mechanical Engineers - Building Services & Industrial</li>
                          <li>• Electrical Engineers - Power & Building Systems</li>
                          <li>• Geotechnical Engineers - Foundation & Earthworks</li>
                          <li>• Environmental Engineers - Sustainability & Compliance</li>
                          <li>• Fire Engineers - Life Safety & Building Code Compliance</li>
                          <li>• Traffic Engineers - Transport & Infrastructure Planning</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-2xl font-semibold text-gray-900 mb-6">
                      Skilled Trades & Construction Labour Recruitment
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Comprehensive recruitment services for qualified tradespeople, apprentices, and construction
                      workers across all building and construction trades. We verify trade qualifications, safety
                      certifications, and ensure compliance with Australian construction standards.
                    </p>

                    <div className="space-y-4">
                      <div className="border-l-4 border-orange-200 pl-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Electrical & Mechanical Trades</h4>
                        <ul className="text-gray-600 space-y-1">
                          <li>• Electricians (A Grade) - Commercial & Industrial</li>
                          <li>• Electrical Supervisors - Major Construction Projects</li>
                          <li>• Plumbers & Gasfitters - Construction & Maintenance</li>
                          <li>• Mechanical Fitters - Industrial & Commercial</li>
                          <li>• HVAC Technicians - Building Services Installation</li>
                          <li>• Instrumentation Technicians - Process & Control Systems</li>
                          <li>• Refrigeration Mechanics - Commercial & Industrial</li>
                          <li>• Fire Protection Technicians - Safety Systems</li>
                        </ul>
                      </div>

                      <div className="border-l-4 border-orange-200 pl-4">
                        <h4 className="font-semibold text-gray-900 mb-2">Building & Construction Trades</h4>
                        <ul className="text-gray-600 space-y-1">
                          <li>• Carpenters & Joiners - Residential & Commercial</li>
                          <li>• Cabinet Makers - Custom & Commercial Fit-outs</li>
                          <li>• Bricklayers & Blocklayers - Structural Construction</li>
                          <li>• Concreters & Formworkers - Foundation & Structural</li>
                          <li>• Tilers & Waterproofers - Finishing Trades</li>
                          <li>• Painters & Decorators - Commercial & Residential</li>
                          <li>• Roofers & Cladding Installers - Building Envelope</li>
                          <li>• Glaziers & Curtain Wall Installers - Commercial Buildings</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-50 p-8 rounded-lg">
                  <h3 className="text-xl font-semibold text-orange-900 mb-4">
                    Construction Recruitment Across Australia
                  </h3>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <h4 className="font-semibold text-orange-800 mb-2">Major Cities</h4>
                      <ul className="text-orange-700 space-y-1">
                        <li>• Construction Recruitment Sydney NSW</li>
                        <li>• Construction Recruitment Melbourne VIC</li>
                        <li>• Construction Recruitment Brisbane QLD</li>
                        <li>• Construction Recruitment Perth WA</li>
                        <li>• Construction Recruitment Adelaide SA</li>
                        <li>• Construction Recruitment Darwin NT</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-orange-800 mb-2">Regional & Remote</h4>
                      <ul className="text-orange-700 space-y-1">
                        <li>• Regional Construction Projects</li>
                        <li>• Mining & Resources Construction</li>
                        <li>• FIFO Construction Roles</li>
                        <li>• Remote Infrastructure Projects</li>
                        <li>• Regional Civil Construction</li>
                        <li>• Country Building Projects</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-orange-800 mb-2">Construction Sectors</h4>
                      <ul className="text-orange-700 space-y-1">
                        <li>• Residential Building & Development</li>
                        <li>• Commercial Construction</li>
                        <li>• Civil Infrastructure & Roads</li>
                        <li>• Industrial & Mining Construction</li>
                        <li>• Rail & Transport Infrastructure</li>
                        <li>• Utilities & Power Generation</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Why Choose The Partnership Group */}
              <div className="bg-emerald-50 p-8 rounded-lg">
                <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
                  Why Choose The Partnership Group for Healthcare or Construction Recruitment?
                </h2>

                <div className="grid lg:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">Industry Specialisation & Expertise</h3>
                    <ul className="space-y-3 text-gray-700">
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-emerald-600 mr-2 mt-1 flex-shrink-0" />
                        <span>Exclusive focus on healthcare and construction recruitment for over 10 years</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-emerald-600 mr-2 mt-1 flex-shrink-0" />
                        <span>Deep understanding of AHPRA requirements and construction safety standards</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-emerald-600 mr-2 mt-1 flex-shrink-0" />
                        <span>Recruitment consultants with healthcare and construction industry backgrounds</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-emerald-600 mr-2 mt-1 flex-shrink-0" />
                        <span>Comprehensive knowledge of industry regulations and compliance requirements</span>
                      </li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-4">National Coverage & Local Expertise</h3>
                    <ul className="space-y-3 text-gray-700">
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-emerald-600 mr-2 mt-1 flex-shrink-0" />
                        <span>Offices in Sydney, Melbourne, Brisbane, Perth, and Adelaide</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-emerald-600 mr-2 mt-1 flex-shrink-0" />
                        <span>Servicing all Australian states and territories including regional areas</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-emerald-600 mr-2 mt-1 flex-shrink-0" />
                        <span>FIFO and interstate relocation services for construction professionals</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-emerald-600 mr-2 mt-1 flex-shrink-0" />
                        <span>Locum and temporary staffing solutions for healthcare facilities</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Call to Action */}
              <div className="text-center">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">
                  Ready to Connect with Australia's Healthcare or Construction Recruitment Specialists?
                </h2>
                <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
                  Whether you're a healthcare facility needing qualified professionals or a construction company seeking
                  skilled workers, The Partnership Group delivers exceptional recruitment results across Australia.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-lg px-8 py-3">
                    <Link href="/register-job">Post Healthcare & Construction Jobs</Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50 text-lg px-8 py-3"
                  >
                    <Link href="/contact">Speak to Our Recruitment Specialists</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TPG</span>
                </div>
                <span className="font-bold text-xl">The Partnership Group</span>
              </div>
              <p className="text-gray-400">
                Australia's premier healthcare or construction recruitment specialists, connecting qualified
                professionals with leading employers across all states and territories.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Healthcare Recruitment</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Nursing Recruitment Australia</li>
                <li>Allied Health Recruitment</li>
                <li>Healthcare Management</li>
                <li>Medical Administration</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Construction Recruitment</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Project Management</li>
                <li>Engineering Recruitment</li>
                <li>Skilled Trades</li>
                <li>Construction Labour</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="text-gray-400 space-y-2">
                <p>1300 TPG JOBS (1300 874 5627)</p>
                <p>info@partnershipgroup.com.au</p>
                <p>
                  Level 15, 1 Martin Place
                  <br />
                  Sydney NSW 2000
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>
              &copy; {new Date().getFullYear()} The Partnership Group - Healthcare & Construction Recruitment
              Specialists Australia. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
