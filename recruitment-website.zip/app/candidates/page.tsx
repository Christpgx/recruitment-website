import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, HardHat, Users, Briefcase, TrendingUp, ArrowRight, FileText, Search } from "lucide-react"
import Image from "next/image"

export default function CandidatesPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">
              Home
            </Link>
            <Link href="/why-us" className="text-gray-700 hover:text-emerald-600 font-medium">
              Why Us
            </Link>
            <Link href="/jobs" className="text-gray-700 hover:text-emerald-600 font-medium">
              Jobs
            </Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">
              Clients
            </Link>
            <Link href="/candidates" className="text-emerald-600 font-medium">
              Candidates
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 font-medium">
              Contact
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Button variant="outline" className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              <Link href="/register-job">Post a Job</Link>
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Link href="/jobs">Find Jobs</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-emerald-50 to-teal-50 py-20">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                  Advance Your <span className="text-emerald-600">Career</span> with Australia's Leading Recruiters
                </h1>
                <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                  Whether you're a healthcare professional or construction expert, we connect you with opportunities
                  that match your skills, values, and career aspirations.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-lg px-8 py-3">
                    <Link href="/register-candidate" className="flex items-center">
                      Register Now <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50 text-lg px-8 py-3"
                  >
                    <Link href="/jobs" className="flex items-center">
                      Browse Jobs <Search className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div>
                <Image
                  src="/placeholder.svg?height=500&width=600"
                  alt="Career advancement illustration"
                  width={600}
                  height={500}
                  className="rounded-lg shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Career Opportunities */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Career Opportunities in Your Field</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We specialise in Healthcare or Construction careers, offering opportunities across all experience levels
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              {/* Healthcare Careers */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <div className="flex items-center mb-4">
                    <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mr-4">
                      <Heart className="h-8 w-8 text-red-600" />
                    </div>
                    <div>
                      <CardTitle className="text-3xl text-gray-900">Healthcare Careers</CardTitle>
                      <p className="text-gray-600">Make a difference in people's lives</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-gray-600 text-lg">
                    From entry-level positions to senior leadership roles, we have opportunities across the healthcare
                    spectrum.
                  </p>

                  <div className="space-y-4">
                    <div className="border-l-4 border-red-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Nursing Opportunities</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Graduate Nurse Programmes</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Registered Nurse - All Specialties</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Nurse Unit Manager Roles</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Clinical Nurse Specialist Positions</span>
                        </li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-red-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Allied Health</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Physiotherapy & Occupational Therapy</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Social Work & Psychology</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Speech Pathology & Dietetics</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Medical Imaging & Laboratory</span>
                        </li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-red-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Healthcare Management</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Department Manager Roles</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Quality & Risk Management</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Healthcare Administration</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-red-600 mr-2 mt-1">•</span>
                          <span>Executive Leadership Positions</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-red-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-red-900 mb-3">Healthcare Benefits</h4>
                    <ul className="space-y-2 text-red-800">
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>Competitive salaries & benefits</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>Professional development opportunities</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>Work-life balance initiatives</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-600 mr-2 mt-1">✓</span>
                        <span>Career progression pathways</span>
                      </li>
                    </ul>
                  </div>

                  <Button className="w-full bg-red-600 hover:bg-red-700">
                    <Link href="/jobs">View Healthcare Jobs</Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Construction Careers */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <div className="flex items-center mb-4">
                    <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mr-4">
                      <HardHat className="h-8 w-8 text-orange-600" />
                    </div>
                    <div>
                      <CardTitle className="text-3xl text-gray-900">Construction Careers</CardTitle>
                      <p className="text-gray-600">Build your future with us</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <p className="text-gray-600 text-lg">
                    From apprenticeships to executive roles, we connect construction professionals with projects that
                    build Australia's future.
                  </p>

                  <div className="space-y-4">
                    <div className="border-l-4 border-orange-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Project Management</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Graduate Project Manager Programmes</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Senior Project Manager Roles</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Construction Manager Positions</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Programme Director Opportunities</span>
                        </li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-orange-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Engineering & Technical</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Civil & Structural Engineering</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Mechanical & Electrical Engineering</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Quantity Surveying</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Building Services Engineering</span>
                        </li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-orange-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Skilled Trades</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Apprenticeship Opportunities</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Qualified Tradesperson Roles</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Supervisory Positions</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-orange-600 mr-2 mt-1">•</span>
                          <span>Specialised Technical Roles</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-orange-900 mb-3">Construction Benefits</h4>
                    <ul className="space-y-2 text-orange-800">
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>Excellent remuneration packages</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>Vehicle & tool allowances</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>Skills development programmes</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-orange-600 mr-2 mt-1">✓</span>
                        <span>Project variety & travel opportunities</span>
                      </li>
                    </ul>
                  </div>

                  <Button className="w-full bg-orange-600 hover:bg-orange-700">
                    <Link href="/jobs">View Construction Jobs</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Why Choose The Partnership Group?</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                We're more than recruiters - we're your career partners, committed to your long-term success
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              <Card className="border-0 shadow-lg text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Users className="h-8 w-8 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Personal Approach</h3>
                  <p className="text-gray-600">
                    We take time to understand your career goals, skills, and preferences to find the perfect match for
                    your next role.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Briefcase className="h-8 w-8 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Exclusive Opportunities</h3>
                  <p className="text-gray-600">
                    Access to roles that aren't advertised elsewhere, including senior positions and unique career
                    opportunities.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <TrendingUp className="h-8 w-8 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Career Development</h3>
                  <p className="text-gray-600">
                    Ongoing support and guidance to help you advance your career, including interview coaching and
                    salary negotiation.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Success Stories */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Success Stories</h2>
              <p className="text-xl text-gray-600">Real people, real career transformations</p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mr-4">
                      <Heart className="h-8 w-8 text-red-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">Jessica Parker</h4>
                      <p className="text-gray-600">Registered Nurse</p>
                    </div>
                  </div>
                  <p className="text-gray-600 italic mb-4">
                    "TPG helped me transition from a small regional hospital to a leading metropolitan facility. The
                    support throughout the process was exceptional, and I'm now working in my dream ICU role with
                    excellent career prospects."
                  </p>
                  <div className="text-sm text-emerald-600 font-semibold">
                    Career advancement: Regional RN → ICU Specialist
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mr-4">
                      <HardHat className="h-8 w-8 text-orange-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">Andrew Wilson</h4>
                      <p className="text-gray-600">Project Manager</p>
                    </div>
                  </div>
                  <p className="text-gray-600 italic mb-4">
                    "After 10 years as a site supervisor, TPG helped me make the leap to project management. They
                    connected me with a company that valued my experience and provided the training I needed to succeed
                    in my new role."
                  </p>
                  <div className="text-sm text-emerald-600 font-semibold">
                    Career advancement: Site Supervisor → Project Manager
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* How It Works */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Getting started with your career journey is simple
              </p>
            </div>

            <div className="grid lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <FileText className="h-8 w-8 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">1. Register</h3>
                <p className="text-gray-600">
                  Complete your profile with your skills, experience, and career preferences.
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">2. Connect</h3>
                <p className="text-gray-600">
                  Our consultants will contact you to discuss your goals and suitable opportunities.
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="h-8 w-8 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">3. Match</h3>
                <p className="text-gray-600">
                  We'll present you with opportunities that align with your skills and career aspirations.
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-8 w-8 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">4. Succeed</h3>
                <p className="text-gray-600">We support you through the interview process and into your new role.</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-emerald-600">
          <div className="container mx-auto px-4 lg:px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Ready to Take the Next Step in Your Career?
            </h2>
            <p className="text-xl text-emerald-100 mb-8 max-w-2xl mx-auto">
              Join thousands of professionals who have advanced their careers with The Partnership Group. Your next
              opportunity is waiting.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                variant="outline"
                className="bg-white text-emerald-600 border-white hover:bg-emerald-50 text-lg px-8 py-3"
              >
                <Link href="/register-candidate">Register Today</Link>
              </Button>
              <Button size="lg" className="bg-emerald-800 hover:bg-emerald-900 text-lg px-8 py-3">
                <Link href="/jobs">Browse Current Jobs</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TPG</span>
                </div>
                <span className="font-bold text-xl">The Partnership Group</span>
              </div>
              <p className="text-gray-400">
                Australia's premier recruitment partnership, connecting talent with opportunity across Healthcare or
                Construction.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/why-us" className="hover:text-white">
                    Why Us
                  </Link>
                </li>
                <li>
                  <Link href="/jobs" className="hover:text-white">
                    Current Jobs
                  </Link>
                </li>
                <li>
                  <Link href="/clients" className="hover:text-white">
                    For Clients
                  </Link>
                </li>
                <li>
                  <Link href="/candidates" className="hover:text-white">
                    For Candidates
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Industries</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Healthcare</li>
                <li>Construction</li>
                <li>Allied Health</li>
                <li>Project Management</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="text-gray-400 space-y-2">
                <p>1300 TPG JOBS</p>
                <p>info@partnershipgroup.com.au</p>
                <p>
                  Level 15, 1 Martin Place
                  <br />
                  Sydney NSW 2000
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} The Partnership Group. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
