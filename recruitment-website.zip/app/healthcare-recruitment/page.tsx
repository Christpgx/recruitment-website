import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, Users, CheckCircle, ArrowRight } from "lucide-react"
import Image from "next/image"

export const metadata: Metadata = {
  title: "Healthcare Recruitment Australia - Nursing & Allied Health Jobs",
  description:
    "Leading healthcare recruitment agency Australia. Specialist nursing recruitment, allied health professionals, healthcare managers. AHPRA registered nurses, ICU, emergency, aged care. Sydney, Melbourne, Brisbane, Perth, Adelaide.",
  keywords: [
    "healthcare recruitment Australia",
    "nursing recruitment Australia",
    "registered nurse jobs Australia",
    "allied health recruitment",
    "healthcare jobs Sydney Melbourne Brisbane",
    "AHPRA nurses recruitment",
    "ICU nurse recruitment",
    "emergency nurse jobs",
    "aged care nursing jobs",
    "healthcare recruitment agency",
    "nursing agency Australia",
    "healthcare professionals recruitment",
    "hospital recruitment Australia",
    "private healthcare recruitment",
  ],
  openGraph: {
    title: "Healthcare Recruitment Australia - Nursing & Allied Health Jobs",
    description:
      "Leading healthcare recruitment agency Australia. Specialist nursing recruitment, allied health professionals, healthcare managers.",
    url: "https://partnershipgroup.com.au/healthcare-recruitment",
  },
  alternates: {
    canonical: "https://partnershipgroup.com.au/healthcare-recruitment",
  },
}

export default function HealthcareRecruitmentPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">
              Home
            </Link>
            <Link href="/why-us" className="text-gray-700 hover:text-emerald-600 font-medium">
              Why Us
            </Link>
            <Link href="/jobs" className="text-gray-700 hover:text-emerald-600 font-medium">
              Jobs
            </Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">
              Clients
            </Link>
            <Link href="/candidates" className="text-gray-700 hover:text-emerald-600 font-medium">
              Candidates
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 font-medium">
              Contact
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Button variant="outline" className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              <Link href="/register-job">Post a Job</Link>
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Link href="/jobs">Find Jobs</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-red-50 to-pink-50 py-20">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Australia's Leading <span className="text-red-600">Healthcare Recruitment</span> Specialists
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Expert healthcare recruitment agency connecting qualified nurses, allied health professionals,
                  healthcare managers, and medical specialists with hospitals, aged care facilities, community health
                  centres, and private practices across Australia. AHPRA registration verification and clinical
                  competency assessment included.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="bg-red-600 hover:bg-red-700 text-lg px-8 py-3">
                    <Link href="/register-job" className="flex items-center">
                      Hire Healthcare Professionals <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="bg-white text-red-600 border-red-600 hover:bg-red-50 text-lg px-8 py-3"
                  >
                    <Link href="/jobs" className="flex items-center">
                      Find Healthcare Jobs <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="relative">
                <Image
                  src="/placeholder.svg?height=500&width=600"
                  alt="Healthcare recruitment specialists Australia - nurses and allied health professionals"
                  width={600}
                  height={500}
                  className="rounded-lg shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Healthcare Recruitment Services */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Comprehensive Healthcare Recruitment Services Australia
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                Specialist healthcare recruitment consultants with deep industry knowledge, AHPRA compliance expertise,
                and extensive networks across Australia's healthcare sector.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8 mb-16">
              {/* Nursing Recruitment */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                    <Heart className="h-8 w-8 text-red-600" />
                  </div>
                  <CardTitle className="text-2xl text-gray-900">Nursing Recruitment Australia</CardTitle>
                  <p className="text-gray-600">Specialist placement of registered and enrolled nurses</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Registered Nurse Recruitment</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• ICU & Critical Care Nurses</li>
                      <li>• Emergency Department Nurses</li>
                      <li>• Theatre & Perioperative Nurses</li>
                      <li>• Medical & Surgical Ward Nurses</li>
                      <li>• Mental Health Nurses</li>
                      <li>• Paediatric & Neonatal Nurses</li>
                      <li>• Aged Care Nurses</li>
                      <li>• Community Health Nurses</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Enrolled Nurse Recruitment</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Acute Care Enrolled Nurses</li>
                      <li>• Aged Care Enrolled Nurses</li>
                      <li>• Medication Endorsed ENs</li>
                      <li>• Community Care ENs</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* Allied Health Recruitment */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                    <Users className="h-8 w-8 text-red-600" />
                  </div>
                  <CardTitle className="text-2xl text-gray-900">Allied Health Recruitment</CardTitle>
                  <p className="text-gray-600">Expert placement of allied health professionals</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2 text-gray-600">
                    <li>• Physiotherapists & Exercise Physiologists</li>
                    <li>• Occupational Therapists</li>
                    <li>• Speech Pathologists & Audiologists</li>
                    <li>• Social Workers & Mental Health Clinicians</li>
                    <li>• Dietitians & Diabetes Educators</li>
                    <li>• Podiatrists & Orthotists</li>
                    <li>• Medical Imaging Technologists</li>
                    <li>• Laboratory Scientists & Technicians</li>
                    <li>• Pharmacy & Healthcare Administration</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Healthcare Management */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <div className="w-16 h-16 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                    <CheckCircle className="h-8 w-8 text-red-600" />
                  </div>
                  <CardTitle className="text-2xl text-gray-900">Healthcare Management</CardTitle>
                  <p className="text-gray-600">Executive and management recruitment</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2 text-gray-600">
                    <li>• Directors of Nursing</li>
                    <li>• Clinical Directors & Managers</li>
                    <li>• Healthcare General Managers</li>
                    <li>• Quality & Risk Managers</li>
                    <li>• Clinical Governance Officers</li>
                    <li>• Healthcare Project Managers</li>
                    <li>• Practice Managers</li>
                    <li>• Health Information Managers</li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* Healthcare Sectors */}
            <div className="bg-red-50 p-8 rounded-lg mb-16">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Healthcare Sectors We Service</h3>
              <div className="grid md:grid-cols-4 gap-6">
                <div>
                  <h4 className="font-semibold text-red-900 mb-3">Public Healthcare</h4>
                  <ul className="space-y-1 text-red-800">
                    <li>• Public Hospitals</li>
                    <li>• Health Districts</li>
                    <li>• Community Health Centres</li>
                    <li>• Mental Health Services</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-red-900 mb-3">Private Healthcare</h4>
                  <ul className="space-y-1 text-red-800">
                    <li>• Private Hospitals</li>
                    <li>• Day Surgery Centres</li>
                    <li>• Specialist Clinics</li>
                    <li>• Medical Centres</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-red-900 mb-3">Aged Care</h4>
                  <ul className="space-y-1 text-red-800">
                    <li>• Residential Aged Care</li>
                    <li>• Home Care Providers</li>
                    <li>• Retirement Villages</li>
                    <li>• Dementia Care Units</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-red-900 mb-3">Primary Care</h4>
                  <ul className="space-y-1 text-red-800">
                    <li>• General Practices</li>
                    <li>• Aboriginal Health Services</li>
                    <li>• Rehabilitation Centres</li>
                    <li>• Disability Services</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Locations */}
            <div className="grid lg:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Healthcare Recruitment Across Australia</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Major Cities</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Healthcare Recruitment Sydney</li>
                      <li>• Healthcare Recruitment Melbourne</li>
                      <li>• Healthcare Recruitment Brisbane</li>
                      <li>• Healthcare Recruitment Perth</li>
                      <li>• Healthcare Recruitment Adelaide</li>
                      <li>• Healthcare Recruitment Canberra</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Regional Areas</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Regional Hospital Recruitment</li>
                      <li>• Rural Healthcare Placements</li>
                      <li>• Remote Area Nursing</li>
                      <li>• Country GP Practice Staff</li>
                      <li>• Regional Allied Health</li>
                      <li>• Rural Mental Health</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Healthcare Recruitment Expertise</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-red-600 mr-2 mt-1 flex-shrink-0" />
                    <span>AHPRA registration verification and compliance monitoring</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-red-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Clinical competency assessment and skills matching</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-red-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Healthcare facility cultural fit evaluation</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-red-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Professional indemnity insurance verification</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-red-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Ongoing professional development support</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-red-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Locum and permanent placement services</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20 bg-red-600">
          <div className="container mx-auto px-4 lg:px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Ready to Partner with Australia's Leading Healthcare Recruiters?
            </h2>
            <p className="text-xl text-red-100 mb-8 max-w-3xl mx-auto">
              Whether you're a healthcare facility needing qualified nurses and allied health professionals, or a
              healthcare professional seeking your next career opportunity, we're here to help.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                variant="outline"
                className="bg-white text-red-600 border-white hover:bg-red-50 text-lg px-8 py-3"
              >
                <Link href="/register-job">Post Healthcare Jobs</Link>
              </Button>
              <Button size="lg" className="bg-red-800 hover:bg-red-900 text-lg px-8 py-3">
                <Link href="/contact">Contact Our Healthcare Team</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TPG</span>
                </div>
                <span className="font-bold text-xl">The Partnership Group</span>
              </div>
              <p className="text-gray-400">
                Australia's premier healthcare recruitment specialists, connecting qualified healthcare professionals
                with leading employers nationwide.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Healthcare Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Nursing Recruitment</li>
                <li>Allied Health Recruitment</li>
                <li>Healthcare Management</li>
                <li>Locum Services</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Locations</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Sydney Healthcare Recruitment</li>
                <li>Melbourne Healthcare Recruitment</li>
                <li>Brisbane Healthcare Recruitment</li>
                <li>National Coverage</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="text-gray-400 space-y-2">
                <p>1300 TPG JOBS</p>
                <p>healthcare@partnershipgroup.com.au</p>
                <p>
                  Level 15, 1 Martin Place
                  <br />
                  Sydney NSW 2000
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>
              &copy; {new Date().getFullYear()} The Partnership Group - Healthcare Recruitment Specialists Australia.
              All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ProfessionalService",
            name: "The Partnership Group - Healthcare Recruitment",
            description:
              "Leading healthcare recruitment agency in Australia specializing in nursing, allied health, and healthcare management recruitment",
            url: "https://partnershipgroup.com.au/healthcare-recruitment",
            serviceType: "Healthcare Recruitment",
            areaServed: {
              "@type": "Country",
              name: "Australia",
            },
            hasOfferCatalog: {
              "@type": "OfferCatalog",
              name: "Healthcare Recruitment Services",
              itemListElement: [
                {
                  "@type": "Offer",
                  itemOffered: {
                    "@type": "Service",
                    name: "Nursing Recruitment",
                    description: "Specialist recruitment for registered nurses, enrolled nurses, and nursing managers",
                  },
                },
                {
                  "@type": "Offer",
                  itemOffered: {
                    "@type": "Service",
                    name: "Allied Health Recruitment",
                    description:
                      "Expert recruitment for physiotherapists, occupational therapists, and allied health professionals",
                  },
                },
              ],
            },
          }),
        }}
      />
    </div>
  )
}
