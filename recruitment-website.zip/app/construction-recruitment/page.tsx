import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { HardHat, Users, CheckCircle, ArrowRight } from "lucide-react"
import Image from "next/image"

export const metadata: Metadata = {
  title: "Construction Recruitment Australia - Project Managers & Skilled Trades",
  description:
    "Leading construction recruitment agency Australia. Expert placement of project managers, engineers, skilled tradespeople, construction workers. White card verified, safety compliant. Sydney, Melbourne, Brisbane, Perth, Adelaide.",
  keywords: [
    "construction recruitment Australia",
    "project manager recruitment Australia",
    "construction jobs Australia",
    "skilled trades recruitment",
    "construction workers Australia",
    "civil engineer recruitment",
    "construction management jobs",
    "electrician recruitment Australia",
    "carpenter recruitment",
    "construction recruitment agency",
    "building recruitment Australia",
    "infrastructure recruitment",
    "FIFO construction jobs",
    "construction project manager",
    "site manager recruitment",
  ],
  openGraph: {
    title: "Construction Recruitment Australia - Project Managers & Skilled Trades",
    description:
      "Leading construction recruitment agency Australia. Expert placement of project managers, engineers, skilled tradespeople.",
    url: "https://partnershipgroup.com.au/construction-recruitment",
  },
  alternates: {
    canonical: "https://partnershipgroup.com.au/construction-recruitment",
  },
}

export default function ConstructionRecruitmentPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">
              Home
            </Link>
            <Link href="/why-us" className="text-gray-700 hover:text-emerald-600 font-medium">
              Why Us
            </Link>
            <Link href="/jobs" className="text-gray-700 hover:text-emerald-600 font-medium">
              Jobs
            </Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">
              Clients
            </Link>
            <Link href="/candidates" className="text-gray-700 hover:text-emerald-600 font-medium">
              Candidates
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 font-medium">
              Contact
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Button variant="outline" className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              <Link href="/register-job">Post a Job</Link>
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Link href="/jobs">Find Jobs</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-orange-50 to-amber-50 py-20">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Australia's Leading <span className="text-orange-600">Construction Recruitment</span> Specialists
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Expert construction recruitment agency connecting project managers, site supervisors, civil engineers,
                  quantity surveyors, skilled tradespeople, and construction workers with major builders, infrastructure
                  companies, and construction firms across Australia. White card verification and safety compliance
                  checks included.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button size="lg" className="bg-orange-600 hover:bg-orange-700 text-lg px-8 py-3">
                    <Link href="/register-job" className="flex items-center">
                      Hire Construction Professionals <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="bg-white text-orange-600 border-orange-600 hover:bg-orange-50 text-lg px-8 py-3"
                  >
                    <Link href="/jobs" className="flex items-center">
                      Find Construction Jobs <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </div>
              </div>
              <div className="relative">
                <Image
                  src="/placeholder.svg?height=500&width=600"
                  alt="Construction recruitment specialists Australia - project managers and skilled trades"
                  width={600}
                  height={500}
                  className="rounded-lg shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Construction Recruitment Services */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Comprehensive Construction Recruitment Services Australia
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                Specialist construction recruitment consultants with deep industry knowledge, safety compliance
                expertise, and extensive networks across Australia's construction sector.
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8 mb-16">
              {/* Management Recruitment */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                    <HardHat className="h-8 w-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-2xl text-gray-900">Construction Management</CardTitle>
                  <p className="text-gray-600">Project managers and construction leaders</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Project Management</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Project Managers - Residential & Commercial</li>
                      <li>• Construction Managers & Site Managers</li>
                      <li>• Site Supervisors & Leading Hands</li>
                      <li>• Contract Administrators</li>
                      <li>• Project Directors</li>
                      <li>• Development Managers</li>
                      <li>• Construction Planners</li>
                      <li>• Quantity Surveyors</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* Engineering & Technical */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                    <Users className="h-8 w-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-2xl text-gray-900">Engineering & Technical</CardTitle>
                  <p className="text-gray-600">Engineers and technical specialists</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2 text-gray-600">
                    <li>• Civil Engineers & Structural Engineers</li>
                    <li>• Mechanical Engineers & Electrical Engineers</li>
                    <li>• Geotechnical Engineers</li>
                    <li>• Environmental Engineers</li>
                    <li>• Building Services Engineers</li>
                    <li>• Fire Engineers</li>
                    <li>• CAD Operators & Design Technicians</li>
                    <li>• Town Planners & Development Managers</li>
                    <li>• Architects & Building Designers</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Skilled Trades */}
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                    <CheckCircle className="h-8 w-8 text-orange-600" />
                  </div>
                  <CardTitle className="text-2xl text-gray-900">Skilled Trades & Labour</CardTitle>
                  <p className="text-gray-600">Qualified tradespeople and construction workers</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Electrical & Mechanical</h4>
                    <ul className="space-y-1 text-gray-600">
                      <li>• Electricians (A Grade)</li>
                      <li>• Electrical Supervisors</li>
                      <li>• Plumbers & Gasfitters</li>
                      <li>• Mechanical Fitters</li>
                      <li>• HVAC Technicians</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Building Trades</h4>
                    <ul className="space-y-1 text-gray-600">
                      <li>• Carpenters & Joiners</li>
                      <li>• Bricklayers & Blocklayers</li>
                      <li>• Concreters & Formworkers</li>
                      <li>• Tilers & Waterproofers</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Construction Sectors */}
            <div className="bg-orange-50 p-8 rounded-lg mb-16">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Construction Sectors We Service</h3>
              <div className="grid md:grid-cols-4 gap-6">
                <div>
                  <h4 className="font-semibold text-orange-900 mb-3">Residential Building</h4>
                  <ul className="space-y-1 text-orange-800">
                    <li>• House & Land Packages</li>
                    <li>• Apartment Developments</li>
                    <li>• Townhouse Projects</li>
                    <li>• Custom Homes</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-900 mb-3">Commercial Construction</h4>
                  <ul className="space-y-1 text-orange-800">
                    <li>• Office Buildings</li>
                    <li>• Retail Developments</li>
                    <li>• Industrial Facilities</li>
                    <li>• Warehouses</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-900 mb-3">Infrastructure</h4>
                  <ul className="space-y-1 text-orange-800">
                    <li>• Roads & Bridges</li>
                    <li>• Rail & Transport</li>
                    <li>• Utilities & Power</li>
                    <li>• Water & Sewerage</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-orange-900 mb-3">Specialist Construction</h4>
                  <ul className="space-y-1 text-orange-800">
                    <li>• Mining & Resources</li>
                    <li>• Oil & Gas Projects</li>
                    <li>• Maintenance & Shutdowns</li>
                    <li>• Fit-out & Refurbishment</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Locations */}
            <div className="grid lg:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Construction Recruitment Across Australia</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Major Cities</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Construction Recruitment Sydney</li>
                      <li>• Construction Recruitment Melbourne</li>
                      <li>• Construction Recruitment Brisbane</li>
                      <li>• Construction Recruitment Perth</li>
                      <li>• Construction Recruitment Adelaide</li>
                      <li>• Construction Recruitment Darwin</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Regional & Remote</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Regional Construction Projects</li>
                      <li>• Mining & Resources Construction</li>
                      <li>• FIFO Construction Roles</li>
                      <li>• Remote Infrastructure Projects</li>
                      <li>• Regional Civil Construction</li>
                      <li>• Country Building Projects</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Construction Recruitment Expertise</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-orange-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Trade qualification verification and licensing</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-orange-600 mr-2 mt-1 flex-shrink-0" />
                    <span>White card and safety certification checks</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-orange-600 mr-2 mt-1 flex-shrink-0" />
                    <span>High risk work licences verification</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-orange-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Project experience matching and skills assessment</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-orange-600 mr-2 mt-1 flex-shrink-0" />
                    <span>Construction industry knowledge and networks</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-orange-600 mr-2 mt-1 flex-shrink-0" />
                    <span>FIFO and interstate placement services</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20 bg-orange-600">
          <div className="container mx-auto px-4 lg:px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Ready to Partner with Australia's Leading Construction Recruiters?
            </h2>
            <p className="text-xl text-orange-100 mb-8 max-w-3xl mx-auto">
              Whether you're a construction company needing skilled professionals, or a construction worker seeking your
              next project opportunity, we're here to help build your future.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                variant="outline"
                className="bg-white text-orange-600 border-white hover:bg-orange-50 text-lg px-8 py-3"
              >
                <Link href="/register-job">Post Construction Jobs</Link>
              </Button>
              <Button size="lg" className="bg-orange-800 hover:bg-orange-900 text-lg px-8 py-3">
                <Link href="/contact">Contact Our Construction Team</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TPG</span>
                </div>
                <span className="font-bold text-xl">The Partnership Group</span>
              </div>
              <p className="text-gray-400">
                Australia's premier construction recruitment specialists, connecting skilled construction professionals
                with leading employers nationwide.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Construction Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Project Management Recruitment</li>
                <li>Engineering Recruitment</li>
                <li>Skilled Trades Recruitment</li>
                <li>FIFO Services</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Locations</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Sydney Construction Recruitment</li>
                <li>Melbourne Construction Recruitment</li>
                <li>Brisbane Construction Recruitment</li>
                <li>National Coverage</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="text-gray-400 space-y-2">
                <p>1300 TPG JOBS</p>
                <p>construction@partnershipgroup.com.au</p>
                <p>
                  Level 15, 1 Martin Place
                  <br />
                  Sydney NSW 2000
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>
              &copy; {new Date().getFullYear()} The Partnership Group - Construction Recruitment Specialists Australia.
              All rights reserved.
            </p>
          </div>
        </div>
      </footer>

      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ProfessionalService",
            name: "The Partnership Group - Construction Recruitment",
            description:
              "Leading construction recruitment agency in Australia specializing in project management, engineering, and skilled trades recruitment",
            url: "https://partnershipgroup.com.au/construction-recruitment",
            serviceType: "Construction Recruitment",
            areaServed: {
              "@type": "Country",
              name: "Australia",
            },
            hasOfferCatalog: {
              "@type": "OfferCatalog",
              name: "Construction Recruitment Services",
              itemListElement: [
                {
                  "@type": "Offer",
                  itemOffered: {
                    "@type": "Service",
                    name: "Project Management Recruitment",
                    description:
                      "Specialist recruitment for construction project managers, site managers, and construction leaders",
                  },
                },
                {
                  "@type": "Offer",
                  itemOffered: {
                    "@type": "Service",
                    name: "Skilled Trades Recruitment",
                    description:
                      "Expert recruitment for electricians, carpenters, plumbers, and skilled construction workers",
                  },
                },
              ],
            },
          }),
        }}
      />
    </div>
  )
}
