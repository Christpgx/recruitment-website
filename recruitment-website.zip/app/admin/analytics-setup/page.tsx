import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle, AlertTriangle, Settings, Code, BarChart3, Search, Target } from "lucide-react"

export default function AnalyticsSetup() {
  const setupItems = [
    {
      service: "Google Analytics 4",
      status: "configured",
      description: "Website traffic and user behavior tracking",
      code: "G-XXXXXXXXXX",
      lastUpdated: "2024-01-15",
    },
    {
      service: "Google Search Console",
      status: "configured",
      description: "Search performance and indexing monitoring",
      code: "Verified",
      lastUpdated: "2024-01-10",
    },
    {
      service: "Google Tag Manager",
      status: "configured",
      description: "Tag and conversion tracking management",
      code: "GTM-XXXXXXX",
      lastUpdated: "2024-01-12",
    },
    {
      service: "Google Ads Conversion Tracking",
      status: "pending",
      description: "Track conversions from Google Ads campaigns",
      code: "AW-XXXXXXXXX",
      lastUpdated: "Not configured",
    },
    {
      service: "Facebook Pixel",
      status: "pending",
      description: "Social media advertising and retargeting",
      code: "Not configured",
      lastUpdated: "Not configured",
    },
    {
      service: "LinkedIn Insight Tag",
      status: "not_configured",
      description: "Professional network advertising tracking",
      code: "Not configured",
      lastUpdated: "Not configured",
    },
  ]

  const conversionGoals = [
    {
      name: "Contact Form Submission",
      type: "Event",
      status: "active",
      value: 50,
      description: "User submits contact form",
    },
    {
      name: "Job Application",
      type: "Event",
      status: "active",
      value: 75,
      description: "User applies for a job",
    },
    {
      name: "Phone Call",
      type: "Event",
      status: "pending",
      value: 100,
      description: "User calls from website",
    },
    {
      name: "CV Upload",
      type: "Event",
      status: "active",
      value: 25,
      description: "User uploads CV/resume",
    },
    {
      name: "Newsletter Signup",
      type: "Event",
      status: "active",
      value: 10,
      description: "User subscribes to newsletter",
    },
  ]

  const seoTools = [
    {
      tool: "SEMrush",
      status: "active",
      purpose: "Keyword research and competitor analysis",
      cost: "$119/month",
      lastSync: "2024-01-20",
    },
    {
      tool: "Ahrefs",
      status: "trial",
      purpose: "Backlink analysis and content research",
      cost: "$99/month",
      lastSync: "2024-01-18",
    },
    {
      tool: "Google PageSpeed Insights",
      status: "active",
      purpose: "Website performance monitoring",
      cost: "Free",
      lastSync: "Daily",
    },
    {
      tool: "Screaming Frog",
      status: "active",
      purpose: "Technical SEO auditing",
      cost: "$149/year",
      lastSync: "Weekly",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics & Tracking Setup</h1>
          <p className="text-gray-600">Configure and monitor your website tracking and analytics tools</p>
        </div>

        {/* Setup Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Configured Tools</p>
                  <p className="text-2xl font-bold text-gray-900">3/6</p>
                </div>
                <Settings className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Goals</p>
                  <p className="text-2xl font-bold text-gray-900">4/5</p>
                </div>
                <Target className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">SEO Tools</p>
                  <p className="text-2xl font-bold text-gray-900">4</p>
                </div>
                <Search className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Data Quality</p>
                  <p className="text-2xl font-bold text-gray-900">87%</p>
                </div>
                <BarChart3 className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Analytics Tools Setup */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Code className="h-5 w-5 mr-2" />
              Analytics & Tracking Tools
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {setupItems.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center">
                    {item.status === "configured" && <CheckCircle className="h-5 w-5 text-green-500 mr-3" />}
                    {item.status === "pending" && <AlertTriangle className="h-5 w-5 text-yellow-500 mr-3" />}
                    {item.status === "not_configured" && <AlertTriangle className="h-5 w-5 text-red-500 mr-3" />}
                    <div>
                      <h4 className="font-semibold">{item.service}</h4>
                      <p className="text-sm text-gray-600">{item.description}</p>
                      <p className="text-xs text-gray-500 mt-1">Code: {item.code}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge
                      variant={
                        item.status === "configured"
                          ? "default"
                          : item.status === "pending"
                            ? "secondary"
                            : "destructive"
                      }
                    >
                      {item.status.replace("_", " ")}
                    </Badge>
                    <p className="text-xs text-gray-500 mt-1">{item.lastUpdated}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Conversion Goals */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center">
                  <Target className="h-5 w-5 mr-2" />
                  Conversion Goals
                </CardTitle>
                <Button size="sm">Add Goal</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {conversionGoals.map((goal, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">{goal.name}</h4>
                      <p className="text-sm text-gray-600">{goal.description}</p>
                      <div className="flex items-center mt-1">
                        <Badge variant="outline" className="mr-2">
                          {goal.type}
                        </Badge>
                        <span className="text-sm text-gray-600">Value: ${goal.value}</span>
                      </div>
                    </div>
                    <Badge variant={goal.status === "active" ? "default" : "secondary"}>{goal.status}</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* SEO Tools */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="h-5 w-5 mr-2" />
                SEO Monitoring Tools
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {seoTools.map((tool, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-semibold">{tool.tool}</h4>
                        <p className="text-sm text-gray-600">{tool.purpose}</p>
                      </div>
                      <Badge
                        variant={
                          tool.status === "active" ? "default" : tool.status === "trial" ? "secondary" : "outline"
                        }
                      >
                        {tool.status}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Cost: {tool.cost}</span>
                      <span className="text-gray-600">Last sync: {tool.lastSync}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Configuration Forms */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Google Ads Setup */}
          <Card>
            <CardHeader>
              <CardTitle>Google Ads Conversion Setup</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Conversion ID</label>
                <Input placeholder="AW-XXXXXXXXX" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Conversion Label</label>
                <Input placeholder="conversion-label" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Conversion Value</label>
                <Input type="number" placeholder="50" />
              </div>
              <Button className="w-full">Configure Google Ads Tracking</Button>
            </CardContent>
          </Card>

          {/* Custom Event Setup */}
          <Card>
            <CardHeader>
              <CardTitle>Custom Event Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Event Name</label>
                <Input placeholder="job_application_submit" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Event Category</label>
                <Input placeholder="engagement" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Event Description</label>
                <Textarea placeholder="User submits job application form" />
              </div>
              <Button className="w-full">Create Custom Event</Button>
            </CardContent>
          </Card>
        </div>

        {/* Implementation Guide */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Implementation Checklist</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold mb-3">Immediate Actions Required</h4>
                <div className="space-y-2">
                  <div className="flex items-center p-2 bg-red-50 rounded">
                    <AlertTriangle className="h-4 w-4 text-red-500 mr-2" />
                    <span className="text-sm">Configure Google Ads conversion tracking</span>
                  </div>
                  <div className="flex items-center p-2 bg-yellow-50 rounded">
                    <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2" />
                    <span className="text-sm">Set up Facebook Pixel for retargeting</span>
                  </div>
                  <div className="flex items-center p-2 bg-yellow-50 rounded">
                    <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2" />
                    <span className="text-sm">Enable phone call tracking</span>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-3">Completed Setup</h4>
                <div className="space-y-2">
                  <div className="flex items-center p-2 bg-green-50 rounded">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Google Analytics 4 configured</span>
                  </div>
                  <div className="flex items-center p-2 bg-green-50 rounded">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Google Search Console verified</span>
                  </div>
                  <div className="flex items-center p-2 bg-green-50 rounded">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Google Tag Manager implemented</span>
                  </div>
                  <div className="flex items-center p-2 bg-green-50 rounded">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Contact form conversion tracking active</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
