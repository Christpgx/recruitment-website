import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, Users, Target, Clock, Award, Shield, Handshake, Briefcase } from "lucide-react"
import Image from "next/image"

export default function WhyUsPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">
              Home
            </Link>
            <Link href="/why-us" className="text-emerald-600 font-medium">
              Why Us
            </Link>
            <Link href="/jobs" className="text-gray-700 hover:text-emerald-600 font-medium">
              Jobs
            </Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">
              Clients
            </Link>
            <Link href="/candidates" className="text-gray-700 hover:text-emerald-600 font-medium">
              Candidates
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 font-medium">
              Contact
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Button variant="outline" className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              <Link href="/register-job">Post a Job</Link>
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Link href="/register-candidate">Find Jobs</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-emerald-50 to-teal-50 py-20">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6">
                Why Choose <span className="text-emerald-600">The Partnership Group</span> for Healthcare or
                Construction Recruitment?
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Australia's most sophisticated healthcare or construction recruitment specialists. We've revolutionised
                traditional recruitment with advanced workforce intelligence, predictive analytics, and comprehensive
                end-to-end solutions that transform how organisations build, manage, and optimise their teams across
                Australia.
              </p>
            </div>
          </div>
        </section>

        {/* Key Differentiators */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid lg:grid-cols-3 gap-8">
              <Card className="border-0 shadow-lg text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Target className="h-8 w-8 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Industry Specialization</h3>
                  <p className="text-gray-600">
                    Deep expertise in Healthcare or Construction means we understand your unique challenges and
                    requirements better than generalist agencies.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Users className="h-8 w-8 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">National Reach</h3>
                  <p className="text-gray-600">
                    With offices across Australia, we connect talent and opportunities from Perth to Brisbane, Darwin to
                    Hobart.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Clock className="h-8 w-8 text-emerald-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Speed & Efficiency</h3>
                  <p className="text-gray-600">
                    Our streamlined processes and extensive networks mean faster placements without compromising on
                    quality.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Comprehensive Service Offering */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Complete Workforce Solutions Beyond Recruitment
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                We don't just find great people - we provide end-to-end workforce management solutions that ensure your
                team is compliant, productive, and fully supported from day one.
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12 mb-16">
              {/* Amazing Onboarding */}
              <Card className="border-0 shadow-xl">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                      <Users className="h-8 w-8 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">Seamless Digital Onboarding</h3>
                      <p className="text-gray-600">Get your team work-ready faster than ever</p>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-6">
                    Our industry-leading digital onboarding platform streamlines the entire process from offer
                    acceptance to first day productivity. No more paperwork delays or compliance headaches.
                  </p>

                  <div className="space-y-4">
                    <div className="border-l-4 border-blue-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Digital Document Management</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Electronic contract signing and document storage</li>
                        <li>• Automated Right to Work verification</li>
                        <li>• Digital ID and qualification verification</li>
                        <li>• Secure cloud-based document repository</li>
                        <li>• Real-time progress tracking for HR teams</li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-blue-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Compliance-First Approach</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Automated AHPRA registration checks for healthcare</li>
                        <li>• Construction white card and safety certification verification</li>
                        <li>• Police check and working with children check coordination</li>
                        <li>• Professional indemnity and public liability insurance tracking</li>
                        <li>• Ongoing compliance monitoring and renewal alerts</li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-blue-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Personalised Onboarding Journey</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Role-specific onboarding checklists and workflows</li>
                        <li>• Interactive company culture and policy training</li>
                        <li>• Buddy system matching for new starters</li>
                        <li>• 30-60-90 day check-in scheduling</li>
                        <li>• Feedback collection and continuous improvement</li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg mt-6">
                    <h4 className="font-semibold text-blue-900 mb-2">Onboarding Results</h4>
                    <div className="grid grid-cols-2 gap-4 text-blue-800">
                      <div>
                        <div className="text-2xl font-bold">75%</div>
                        <div className="text-sm">Faster time to productivity</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">90%</div>
                        <div className="text-sm">New hire satisfaction rate</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Workforce Management */}
              <Card className="border-0 shadow-xl">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                      <Briefcase className="h-8 w-8 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">Advanced Workforce Management</h3>
                      <p className="text-gray-600">Complete visibility and control over your workforce</p>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-6">
                    Our comprehensive workforce management platform gives you real-time insights into your team's
                    performance, compliance status, and operational efficiency across all locations.
                  </p>

                  <div className="space-y-4">
                    <div className="border-l-4 border-purple-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Real-Time Workforce Analytics</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Live dashboard showing staff locations and status</li>
                        <li>• Attendance and punctuality tracking</li>
                        <li>• Performance metrics and KPI monitoring</li>
                        <li>• Skill matrix and competency tracking</li>
                        <li>• Predictive analytics for workforce planning</li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-purple-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Intelligent Scheduling & Rostering</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• AI-powered shift scheduling and optimisation</li>
                        <li>• Skills-based staff allocation</li>
                        <li>• Automated overtime and penalty rate calculations</li>
                        <li>• Mobile app for shift swaps and availability updates</li>
                        <li>• Integration with payroll and HR systems</li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-purple-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Performance & Development Tracking</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Continuous performance monitoring and feedback</li>
                        <li>• Skills gap analysis and training recommendations</li>
                        <li>• Career pathway planning and progression tracking</li>
                        <li>• 360-degree feedback collection and analysis</li>
                        <li>• Recognition and reward program management</li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-purple-50 p-4 rounded-lg mt-6">
                    <h4 className="font-semibold text-purple-900 mb-2">Workforce Management Benefits</h4>
                    <div className="grid grid-cols-2 gap-4 text-purple-800">
                      <div>
                        <div className="text-2xl font-bold">40%</div>
                        <div className="text-sm">Reduction in admin time</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">25%</div>
                        <div className="text-sm">Improvement in productivity</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              {/* Compliance Management */}
              <Card className="border-0 shadow-xl">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                      <Shield className="h-8 w-8 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">Comprehensive Compliance Management</h3>
                      <p className="text-gray-600">Stay compliant with automated monitoring and alerts</p>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-6">
                    Our compliance management system ensures your workforce meets all regulatory requirements with
                    automated tracking, renewal alerts, and comprehensive audit trails.
                  </p>

                  <div className="space-y-4">
                    <div className="border-l-4 border-green-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Healthcare Compliance</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• AHPRA registration monitoring and renewal alerts</li>
                        <li>• CPD requirements tracking and compliance reporting</li>
                        <li>• Professional indemnity insurance verification</li>
                        <li>• Immunisation and health screening management</li>
                        <li>• Mandatory training completion tracking</li>
                        <li>• Incident reporting and management system</li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-green-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Construction Compliance</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• White card and safety certification tracking</li>
                        <li>• High-risk work licence monitoring</li>
                        <li>• Trade qualification verification and updates</li>
                        <li>• WHS training and competency management</li>
                        <li>• Site-specific induction tracking</li>
                        <li>• Safety incident reporting and analysis</li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-green-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">General Compliance</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Right to Work verification and monitoring</li>
                        <li>• Police check and background screening</li>
                        <li>• Working with Children Check management</li>
                        <li>• Fair Work Act compliance monitoring</li>
                        <li>• Award interpretation and penalty rate calculations</li>
                        <li>• Audit trail maintenance and reporting</li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg mt-6">
                    <h4 className="font-semibold text-green-900 mb-2">Compliance Assurance</h4>
                    <ul className="space-y-1 text-green-800">
                      <li>✓ 100% compliance tracking and monitoring</li>
                      <li>✓ Automated renewal alerts and notifications</li>
                      <li>✓ Comprehensive audit trails and reporting</li>
                      <li>✓ Regular compliance health checks</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>

              {/* Timesheeting & Payroll */}
              <Card className="border-0 shadow-xl">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mr-4">
                      <Clock className="h-8 w-8 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">Smart Timesheeting & Payroll Integration</h3>
                      <p className="text-gray-600">Accurate time tracking with seamless payroll processing</p>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-6">
                    Our intelligent timesheeting system captures accurate work hours with GPS verification, automated
                    award calculations, and direct integration with major payroll platforms.
                  </p>

                  <div className="space-y-4">
                    <div className="border-l-4 border-orange-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Advanced Time Capture</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• GPS-verified clock in/out with geofencing</li>
                        <li>• Photo verification for remote workers</li>
                        <li>• Biometric time clocks for secure facilities</li>
                        <li>• Mobile app with offline capability</li>
                        <li>• Break and meal time automatic deductions</li>
                        <li>• Project and cost centre allocation</li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-orange-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Intelligent Award Calculations</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Automatic overtime and penalty rate calculations</li>
                        <li>• Shift allowances and loading applications</li>
                        <li>• Public holiday and weekend premium rates</li>
                        <li>• Travel time and allowance calculations</li>
                        <li>• Multi-award and EBA compliance</li>
                        <li>• Custom pay rules and exceptions handling</li>
                      </ul>
                    </div>

                    <div className="border-l-4 border-orange-200 pl-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Seamless Payroll Integration</h4>
                      <ul className="space-y-1 text-gray-600">
                        <li>• Direct integration with MYOB, Xero, and SAP</li>
                        <li>• Automated timesheet approval workflows</li>
                        <li>• Exception reporting and variance analysis</li>
                        <li>• Single Touch Payroll (STP) compliance</li>
                        <li>• Superannuation and leave accrual calculations</li>
                        <li>• Comprehensive payroll reporting and analytics</li>
                      </ul>
                    </div>
                  </div>

                  <div className="bg-orange-50 p-4 rounded-lg mt-6">
                    <h4 className="font-semibold text-orange-900 mb-2">Timesheeting Efficiency</h4>
                    <div className="grid grid-cols-2 gap-4 text-orange-800">
                      <div>
                        <div className="text-2xl font-bold">95%</div>
                        <div className="text-sm">Timesheet accuracy rate</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold">80%</div>
                        <div className="text-sm">Reduction in payroll processing time</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Technology Platform Overview */}
            {/* Integrated Workforce Ecosystem */}
            <div className="mt-16">
              <Card className="border-0 shadow-xl bg-gradient-to-r from-emerald-50 to-teal-50">
                <CardContent className="p-8">
                  <div className="text-center mb-8">
                    <h3 className="text-3xl font-bold text-gray-900 mb-4">Integrated Workforce Ecosystem</h3>
                    <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                      Our comprehensive platform creates a seamless ecosystem where recruitment, onboarding, workforce
                      management, and performance optimisation work together to deliver unprecedented results.
                    </p>
                  </div>

                  <div className="grid lg:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Users className="h-8 w-8 text-emerald-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-2">Intelligent Onboarding</h4>
                      <p className="text-gray-600 text-sm">AI-driven personalisation and automation</p>
                    </div>

                    <div className="text-center">
                      <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Briefcase className="h-8 w-8 text-emerald-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-2">Predictive Management</h4>
                      <p className="text-gray-600 text-sm">Proactive workforce optimisation</p>
                    </div>

                    <div className="text-center">
                      <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Shield className="h-8 w-8 text-emerald-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-2">Proactive Compliance</h4>
                      <p className="text-gray-600 text-sm">Predictive risk management</p>
                    </div>

                    <div className="text-center">
                      <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Clock className="h-8 w-8 text-emerald-600" />
                      </div>
                      <h4 className="font-semibold text-gray-900 mb-2">Intelligent Analytics</h4>
                      <p className="text-gray-600 text-sm">Data-driven decision making</p>
                    </div>
                  </div>

                  <div className="text-center mt-8">
                    <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-lg px-8 py-3">
                      <Link href="/contact">Discover Our Advanced Solutions</Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Industry Expertise Section */}
        {/* Advanced Recruitment Intelligence */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Advanced Recruitment Intelligence & Market Insights
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                We leverage proprietary data analytics, market intelligence, and predictive modelling to identify talent
                before your competitors even know they exist. Our approach goes far beyond traditional recruitment
                methods.
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Healthcare Talent Intelligence</h3>
                <div className="space-y-6">
                  <div className="border-l-4 border-red-200 pl-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Predictive Career Mapping</h4>
                    <p className="text-gray-600">
                      Advanced algorithms analyse career progression patterns, identifying high-potential candidates
                      6-12 months before they actively seek new opportunities. We map entire healthcare ecosystems to
                      predict talent movement.
                    </p>
                  </div>
                  <div className="border-l-4 border-red-200 pl-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Competency-Based Matching</h4>
                    <p className="text-gray-600">
                      Proprietary assessment frameworks that evaluate not just qualifications, but cognitive abilities,
                      emotional intelligence, cultural adaptability, and leadership potential specific to healthcare
                      environments.
                    </p>
                  </div>
                  <div className="border-l-4 border-red-200 pl-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Healthcare Market Intelligence</h4>
                    <p className="text-gray-600">
                      Real-time salary benchmarking, workforce shortage predictions, and competitive intelligence across
                      public and private healthcare sectors. We know which facilities are expanding before they announce
                      it.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Construction Talent Intelligence</h3>
                <div className="space-y-6">
                  <div className="border-l-4 border-orange-200 pl-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Project Pipeline Analytics</h4>
                    <p className="text-gray-600">
                      Comprehensive tracking of infrastructure projects, development approvals, and construction tenders
                      across Australia. We position talent strategically before projects commence, ensuring immediate
                      availability.
                    </p>
                  </div>
                  <div className="border-l-4 border-orange-200 pl-6">
                    <h4 className="font-semibent text-gray-900 mb-2">Skills Scarcity Modelling</h4>
                    <p className="text-gray-600">
                      Advanced analytics identifying emerging skill shortages, technology adoption impacts, and
                      workforce demographic shifts. We proactively develop talent pipelines for future industry needs.
                    </p>
                  </div>
                  <div className="border-l-4 border-orange-200 pl-6">
                    <h4 className="font-semibold text-gray-900 mb-2">Performance Correlation Analysis</h4>
                    <p className="text-gray-600">
                      Data-driven insights linking candidate characteristics to project success metrics, safety
                      performance, and team productivity. Our placements consistently outperform industry benchmarks.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Our Approach */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">Our Partnership Approach</h2>
                <p className="text-xl text-gray-600 mb-8">
                  We believe in building long-term partnerships, not just filling positions. Our approach is built on
                  understanding, trust, and delivering exceptional results.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Deep Discovery Process</h4>
                      <p className="text-gray-600">
                        We take time to understand your culture, values, and specific requirements
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Rigorous Screening</h4>
                      <p className="text-gray-600">
                        Multi-stage assessment including skills, cultural fit, and reference checks
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-6 w-6 text-emerald-600 mr-3 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Ongoing Support</h4>
                      <p className="text-gray-600">
                        We support both parties through onboarding and beyond to ensure success
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <Image
                  src="/placeholder.svg?height=400&width=500"
                  alt="Partnership approach illustration"
                  width={500}
                  height={400}
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">Our Core Values</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                These principles guide everything we do and define how we work with our clients and candidates
              </p>
            </div>
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Shield className="h-10 w-10 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Integrity</h3>
                <p className="text-gray-600">
                  Honest, transparent communication and ethical practices in all our interactions
                </p>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="h-10 w-10 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Excellence</h3>
                <p className="text-gray-600">Commitment to delivering exceptional results and exceeding expectations</p>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Handshake className="h-10 w-10 text-emerald-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Partnership</h3>
                <p className="text-gray-600">Building lasting relationships based on mutual trust and shared success</p>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">What Our Partners Say</h2>
            </div>
            <div className="grid lg:grid-cols-2 gap-8">
              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <p className="text-gray-600 mb-6 italic">
                    "The Partnership Group transformed our hiring process. Their deep understanding of healthcare
                    recruitment and commitment to finding the right cultural fit has been exceptional."
                  </p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-red-600 font-bold">SH</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Sarah Mitchell</div>
                      <div className="text-gray-600">HR Director, Sydney Healthcare Group</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg">
                <CardContent className="p-8">
                  <p className="text-gray-600 mb-6 italic">
                    "Working with TPG has been a game-changer for our construction projects. They consistently deliver
                    skilled professionals who hit the ground running."
                  </p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mr-4">
                      <span className="text-orange-600 font-bold">MR</span>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">David Thompson</div>
                      <div className="text-gray-600">Operations Manager, Premier Construction Group</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-emerald-600">
          <div className="container mx-auto px-4 lg:px-6 text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">Ready to Experience the Difference?</h2>
            <p className="text-xl text-emerald-100 mb-8 max-w-2xl mx-auto">
              Join hundreds of satisfied clients and candidates who have discovered what makes The Partnership Group
              different.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                variant="outline"
                className="bg-white text-emerald-600 border-white hover:bg-emerald-50 text-lg px-8 py-3"
              >
                <Link href="/register-job">Start Hiring Today</Link>
              </Button>
              <Button size="lg" className="bg-emerald-800 hover:bg-emerald-900 text-lg px-8 py-3">
                <Link href="/contact">Get in Touch</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TPG</span>
                </div>
                <span className="font-bold text-xl">The Partnership Group</span>
              </div>
              <p className="text-gray-400">
                Australia's premier recruitment partnership, connecting talent with opportunity across Healthcare or
                Construction.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/why-us" className="hover:text-white">
                    Why Us
                  </Link>
                </li>
                <li>
                  <Link href="/jobs" className="hover:text-white">
                    Current Jobs
                  </Link>
                </li>
                <li>
                  <Link href="/clients" className="hover:text-white">
                    For Clients
                  </Link>
                </li>
                <li>
                  <Link href="/candidates" className="hover:text-white">
                    For Candidates
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Industries</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Healthcare</li>
                <li>Construction</li>
                <li>Allied Health</li>
                <li>Project Management</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="text-gray-400 space-y-2">
                <p>1300 TPG JOBS</p>
                <p>info@partnershipgroup.com.au</p>
                <p>
                  Level 15, 1 Martin Place
                  <br />
                  Sydney NSW 2000
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} The Partnership Group. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
