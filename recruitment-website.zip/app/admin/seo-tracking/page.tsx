import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, TrendingUp, TrendingDown, AlertTriangle, CheckCircle, Target } from "lucide-react"

export default function SEOTracking() {
  const keywordData = [
    {
      keyword: "healthcare recruitment australia",
      currentPosition: 3,
      previousPosition: 5,
      searchVolume: 1200,
      difficulty: 65,
      url: "/healthcare-recruitment",
      trend: "up",
      clicks: 247,
      impressions: 3421,
    },
    {
      keyword: "construction recruitment sydney",
      currentPosition: 5,
      previousPosition: 7,
      searchVolume: 890,
      difficulty: 58,
      url: "/construction-recruitment",
      trend: "up",
      clicks: 189,
      impressions: 2876,
    },
    {
      keyword: "nursing jobs melbourne",
      currentPosition: 2,
      previousPosition: 2,
      searchVolume: 1560,
      difficulty: 72,
      url: "/healthcare-recruitment",
      trend: "stable",
      clicks: 312,
      impressions: 4123,
    },
    {
      keyword: "project manager recruitment",
      currentPosition: 7,
      previousPosition: 6,
      searchVolume: 650,
      difficulty: 61,
      url: "/construction-recruitment",
      trend: "down",
      clicks: 98,
      impressions: 1876,
    },
    {
      keyword: "allied health recruitment",
      currentPosition: 4,
      previousPosition: 6,
      searchVolume: 720,
      difficulty: 55,
      url: "/healthcare-recruitment",
      trend: "up",
      clicks: 156,
      impressions: 2341,
    },
  ]

  const competitorData = [
    {
      competitor: "Healthcare Recruitment Co",
      domain: "healthcarerecruitment.com.au",
      avgPosition: 2.3,
      visibility: 78,
      keywords: 234,
      trend: "up",
    },
    {
      competitor: "Construction Jobs Plus",
      domain: "constructionjobsplus.com.au",
      avgPosition: 3.1,
      visibility: 65,
      keywords: 189,
      trend: "stable",
    },
    {
      competitor: "Nursing Careers Australia",
      domain: "nursingcareers.com.au",
      avgPosition: 4.2,
      visibility: 52,
      keywords: 156,
      trend: "down",
    },
  ]

  const technicalIssues = [
    {
      issue: "Page Speed",
      status: "warning",
      description: "3 pages loading slower than 3 seconds",
      priority: "high",
    },
    {
      issue: "Mobile Usability",
      status: "good",
      description: "All pages mobile-friendly",
      priority: "low",
    },
    {
      issue: "Core Web Vitals",
      status: "warning",
      description: "LCP needs improvement on 2 pages",
      priority: "medium",
    },
    {
      issue: "Schema Markup",
      status: "good",
      description: "All pages have proper schema",
      priority: "low",
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">SEO Keyword Tracking</h1>
          <p className="text-gray-600">Monitor keyword rankings and SEO performance</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Keywords</p>
                  <p className="text-2xl font-bold text-gray-900">127</p>
                </div>
                <Target className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Top 3 Rankings</p>
                  <p className="text-2xl font-bold text-gray-900">23</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg Position</p>
                  <p className="text-2xl font-bold text-gray-900">4.2</p>
                </div>
                <Search className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Visibility Score</p>
                  <p className="text-2xl font-bold text-gray-900">67%</p>
                </div>
                <CheckCircle className="h-8 w-8 text-emerald-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Keyword Tracking Table */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Keyword Performance</CardTitle>
              <div className="flex gap-2">
                <Input placeholder="Search keywords..." className="w-64" />
                <Button>Add Keyword</Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3">Keyword</th>
                    <th className="text-left p-3">Position</th>
                    <th className="text-left p-3">Change</th>
                    <th className="text-left p-3">Search Volume</th>
                    <th className="text-left p-3">Difficulty</th>
                    <th className="text-left p-3">Clicks</th>
                    <th className="text-left p-3">CTR</th>
                    <th className="text-left p-3">URL</th>
                  </tr>
                </thead>
                <tbody>
                  {keywordData.map((keyword, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div>
                          <p className="font-medium">{keyword.keyword}</p>
                        </div>
                      </td>
                      <td className="p-3">
                        <Badge variant="outline" className="font-mono">
                          #{keyword.currentPosition}
                        </Badge>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center">
                          {keyword.trend === "up" && (
                            <>
                              <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                              <span className="text-green-600 text-sm">
                                +{keyword.previousPosition - keyword.currentPosition}
                              </span>
                            </>
                          )}
                          {keyword.trend === "down" && (
                            <>
                              <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                              <span className="text-red-600 text-sm">
                                -{keyword.currentPosition - keyword.previousPosition}
                              </span>
                            </>
                          )}
                          {keyword.trend === "stable" && <span className="text-gray-500 text-sm">No change</span>}
                        </div>
                      </td>
                      <td className="p-3">{keyword.searchVolume.toLocaleString()}</td>
                      <td className="p-3">
                        <Badge
                          variant={
                            keyword.difficulty > 70 ? "destructive" : keyword.difficulty > 50 ? "secondary" : "default"
                          }
                        >
                          {keyword.difficulty}%
                        </Badge>
                      </td>
                      <td className="p-3">{keyword.clicks}</td>
                      <td className="p-3">{((keyword.clicks / keyword.impressions) * 100).toFixed(1)}%</td>
                      <td className="p-3">
                        <code className="text-xs bg-gray-100 px-2 py-1 rounded">{keyword.url}</code>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Competitor Analysis */}
          <Card>
            <CardHeader>
              <CardTitle>Competitor Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {competitorData.map((competitor, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-semibold">{competitor.competitor}</h4>
                        <p className="text-sm text-gray-600">{competitor.domain}</p>
                      </div>
                      <Badge
                        variant={
                          competitor.trend === "up"
                            ? "default"
                            : competitor.trend === "down"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {competitor.trend}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Avg Position</p>
                        <p className="font-semibold">{competitor.avgPosition}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Visibility</p>
                        <p className="font-semibold">{competitor.visibility}%</p>
                      </div>
                      <div>
                        <p className="text-gray-600">Keywords</p>
                        <p className="font-semibold">{competitor.keywords}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Technical SEO Issues */}
          <Card>
            <CardHeader>
              <CardTitle>Technical SEO Health</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {technicalIssues.map((issue, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center">
                      {issue.status === "good" && <CheckCircle className="h-5 w-5 text-green-500 mr-3" />}
                      {issue.status === "warning" && <AlertTriangle className="h-5 w-5 text-yellow-500 mr-3" />}
                      {issue.status === "error" && <AlertTriangle className="h-5 w-5 text-red-500 mr-3" />}
                      <div>
                        <p className="font-medium">{issue.issue}</p>
                        <p className="text-sm text-gray-600">{issue.description}</p>
                      </div>
                    </div>
                    <Badge
                      variant={
                        issue.priority === "high"
                          ? "destructive"
                          : issue.priority === "medium"
                            ? "secondary"
                            : "outline"
                      }
                    >
                      {issue.priority}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Items */}
        <Card>
          <CardHeader>
            <CardTitle>SEO Action Plan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-red-800">Urgent: Improve "project manager recruitment"</h4>
                    <p className="text-sm text-red-700">Dropped from position 6 to 7. Competitor gaining ground.</p>
                  </div>
                  <Button size="sm" className="bg-red-600 hover:bg-red-700">
                    Fix Now
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-yellow-800">Opportunity: Target "FIFO construction jobs"</h4>
                    <p className="text-sm text-yellow-700">Low competition keyword with 450 monthly searches.</p>
                  </div>
                  <Button size="sm" className="bg-yellow-600 hover:bg-yellow-700">
                    Create Content
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-green-800">Success: "nursing jobs melbourne" ranking #2</h4>
                    <p className="text-sm text-green-700">Maintain current content quality and build more backlinks.</p>
                  </div>
                  <Button size="sm" className="bg-green-600 hover:bg-green-700">
                    Maintain
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
