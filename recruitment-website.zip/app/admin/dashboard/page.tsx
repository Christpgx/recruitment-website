import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Users, Search, MapPin, Heart, HardHat, Eye, MousePointer, Mail } from "lucide-react"

export default function AdminDashboard() {
  // This would typically come from your analytics API
  const analyticsData = {
    totalVisitors: 12847,
    organicTraffic: 8934,
    conversionRate: 3.2,
    topKeywords: [
      { keyword: "healthcare recruitment australia", position: 3, traffic: 1247, trend: "up" },
      { keyword: "construction recruitment sydney", position: 5, traffic: 892, trend: "up" },
      { keyword: "nursing jobs melbourne", position: 2, traffic: 1156, trend: "stable" },
      { keyword: "project manager recruitment", position: 7, traffic: 634, trend: "down" },
      { keyword: "allied health recruitment", position: 4, traffic: 723, trend: "up" },
    ],
    topPages: [
      { page: "/healthcare-recruitment", views: 3421, conversions: 89 },
      { page: "/construction-recruitment", views: 2876, conversions: 76 },
      { page: "/jobs", views: 2134, conversions: 45 },
      { page: "/", views: 1987, conversions: 32 },
    ],
    trafficSources: [
      { source: "Organic Search", percentage: 69.5, visitors: 8934 },
      { source: "Direct", percentage: 18.2, visitors: 2338 },
      { source: "Social Media", percentage: 7.8, visitors: 1002 },
      { source: "Referral", percentage: 4.5, visitors: 578 },
    ],
    locationData: [
      { city: "Sydney", visitors: 3421, conversions: 89 },
      { city: "Melbourne", visitors: 2876, conversions: 76 },
      { city: "Brisbane", visitors: 2134, conversions: 45 },
      { city: "Perth", visitors: 1987, conversions: 32 },
      { city: "Adelaide", visitors: 1456, conversions: 28 },
    ],
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">SEO & Analytics Dashboard</h1>
          <p className="text-gray-600">Monitor your website performance and SEO metrics</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Visitors</p>
                  <p className="text-2xl font-bold text-gray-900">{analyticsData.totalVisitors.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-sm text-green-600">+12.5% from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Organic Traffic</p>
                  <p className="text-2xl font-bold text-gray-900">{analyticsData.organicTraffic.toLocaleString()}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Search className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-sm text-green-600">+18.3% from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                  <p className="text-2xl font-bold text-gray-900">{analyticsData.conversionRate}%</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <MousePointer className="h-6 w-6 text-purple-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-sm text-green-600">+0.8% from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Lead Generation</p>
                  <p className="text-2xl font-bold text-gray-900">287</p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Mail className="h-6 w-6 text-orange-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-sm text-green-600">+24.1% from last month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Top Keywords */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="h-5 w-5 mr-2" />
                Top Performing Keywords
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.topKeywords.map((keyword, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{keyword.keyword}</p>
                      <div className="flex items-center mt-1">
                        <Badge variant="outline" className="mr-2">
                          Position #{keyword.position}
                        </Badge>
                        <span className="text-sm text-gray-600">{keyword.traffic} monthly searches</span>
                      </div>
                    </div>
                    <div className="flex items-center">
                      {keyword.trend === "up" && <TrendingUp className="h-4 w-4 text-green-500" />}
                      {keyword.trend === "down" && <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />}
                      {keyword.trend === "stable" && <div className="w-4 h-4 bg-gray-400 rounded-full" />}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Pages */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Eye className="h-5 w-5 mr-2" />
                Top Performing Pages
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.topPages.map((page, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{page.page}</p>
                      <div className="flex items-center mt-1">
                        <span className="text-sm text-gray-600 mr-4">{page.views} views</span>
                        <span className="text-sm text-green-600">{page.conversions} conversions</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">
                        {((page.conversions / page.views) * 100).toFixed(1)}%
                      </p>
                      <p className="text-xs text-gray-500">conversion rate</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Traffic Sources */}
          <Card>
            <CardHeader>
              <CardTitle>Traffic Sources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.trafficSources.map((source, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                      <span className="font-medium text-gray-900">{source.source}</span>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">{source.percentage}%</p>
                      <p className="text-sm text-gray-600">{source.visitors.toLocaleString()} visitors</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Location Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                Performance by Location
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.locationData.map((location, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{location.city}</p>
                      <p className="text-sm text-gray-600">{location.visitors} visitors</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">{location.conversions}</p>
                      <p className="text-xs text-gray-500">conversions</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Industry Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Heart className="h-5 w-5 mr-2 text-red-600" />
                Healthcare Recruitment Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Page Views</span>
                  <span className="font-semibold">3,421</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Conversions</span>
                  <span className="font-semibold">89</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Top Keywords</span>
                  <span className="font-semibold">nursing recruitment, AHPRA</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Avg. Session Duration</span>
                  <span className="font-semibold">4:32</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <HardHat className="h-5 w-5 mr-2 text-orange-600" />
                Construction Recruitment Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Page Views</span>
                  <span className="font-semibold">2,876</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Conversions</span>
                  <span className="font-semibold">76</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Top Keywords</span>
                  <span className="font-semibold">project manager, white card</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Avg. Session Duration</span>
                  <span className="font-semibold">3:47</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Items */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Recommended Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-2">Improve "project manager recruitment"</h4>
                <p className="text-sm text-yellow-700">
                  Currently ranking #7 - optimize content and build more backlinks
                </p>
                <Button size="sm" className="mt-2 bg-yellow-600 hover:bg-yellow-700">
                  View Details
                </Button>
              </div>
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">Expand Brisbane content</h4>
                <p className="text-sm text-green-700">
                  High conversion rate - create more Brisbane-specific landing pages
                </p>
                <Button size="sm" className="mt-2 bg-green-600 hover:bg-green-700">
                  Create Content
                </Button>
              </div>
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-semibold text-blue-800 mb-2">Mobile optimization</h4>
                <p className="text-sm text-blue-700">67% mobile traffic - ensure all pages are mobile-optimized</p>
                <Button size="sm" className="mt-2 bg-blue-600 hover:bg-blue-700">
                  Check Mobile
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
