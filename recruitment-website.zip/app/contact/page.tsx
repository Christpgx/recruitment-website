import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Mail, Clock } from "lucide-react"

export default function ContactPage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">
              Home
            </Link>
            <Link href="/why-us" className="text-gray-700 hover:text-emerald-600 font-medium">
              Why Us
            </Link>
            <Link href="/jobs" className="text-gray-700 hover:text-emerald-600 font-medium">
              Jobs
            </Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">
              Clients
            </Link>
            <Link href="/candidates" className="text-gray-700 hover:text-emerald-600 font-medium">
              Candidates
            </Link>
            <Link href="/contact" className="text-emerald-600 font-medium">
              Contact
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Button variant="outline" className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              <Link href="/register-job">Post a Job</Link>
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Link href="/register-candidate">Find Jobs</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-emerald-50 to-teal-50 py-16">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                Get in <span className="text-emerald-600">Touch</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Ready to start your recruitment journey? We're here to help across all Australian states and
                territories.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Information */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <div>
                <Card className="border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="text-2xl text-gray-900">Send us a Message</CardTitle>
                    <p className="text-gray-600">We'll get back to you within 24 hours</p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                        <Input placeholder="John" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                        <Input placeholder="Smith" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                      <Input type="email" placeholder="john.smith@email.com" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                      <Input type="tel" placeholder="0400 000 000" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">I am a...</label>
                      <select className="w-full border border-gray-300 rounded-md px-3 py-2">
                        <option>Select an option</option>
                        <option>Job Seeker</option>
                        <option>Employer looking to hire</option>
                        <option>General Inquiry</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Industry Interest</label>
                      <select className="w-full border border-gray-300 rounded-md px-3 py-2">
                        <option>Select an industry</option>
                        <option>Healthcare</option>
                        <option>Construction</option>
                        <option>Both Healthcare and Construction</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                      <Textarea
                        placeholder="Tell us about your requirements or how we can help..."
                        className="min-h-[120px]"
                      />
                    </div>
                    <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Send Message</Button>
                  </CardContent>
                </Card>
              </div>

              {/* Contact Details */}
              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-6">Contact Information</h2>
                  <p className="text-gray-600 text-lg mb-8">
                    We're here to help you succeed. Reach out to us through any of the following channels.
                  </p>
                </div>

                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mr-4">
                      <Phone className="h-6 w-6 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Phone</h4>
                      <p className="text-gray-600">1300 TPG JOBS (1300 874 5627)</p>
                      <p className="text-gray-600">+61 2 9000 0000</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mr-4">
                      <Mail className="h-6 w-6 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Email</h4>
                      <p className="text-gray-600">info@partnershipgroup.com.au</p>
                      <p className="text-gray-600">careers@partnershipgroup.com.au</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mr-4">
                      <Clock className="h-6 w-6 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-1">Business Hours</h4>
                      <p className="text-gray-600">Monday - Friday: 8:00 AM - 6:00 PM</p>
                      <p className="text-gray-600">Saturday: 9:00 AM - 1:00 PM</p>
                      <p className="text-gray-600">Sunday: Closed</p>
                    </div>
                  </div>
                </div>

                <div className="bg-emerald-50 p-6 rounded-lg">
                  <h4 className="font-semibold text-emerald-900 mb-3">Quick Actions</h4>
                  <div className="space-y-3">
                    <Button
                      variant="outline"
                      className="w-full bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50"
                    >
                      <Link href="/register-job">Post a Job Opportunity</Link>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50"
                    >
                      <Link href="/register-candidate">Register as a Candidate</Link>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50"
                    >
                      <Link href="/jobs">Browse Current Jobs</Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Office Locations */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Locations</h2>
              <p className="text-xl text-gray-600">Serving clients and candidates across Australia</p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Sydney - Head Office */}
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <MapPin className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-xl font-bold text-gray-900">Sydney - Head Office</h3>
                  </div>
                  <div className="space-y-2 text-gray-600">
                    <p>Level 15, 1 Martin Place</p>
                    <p>Sydney NSW 2000</p>
                    <p className="font-semibold text-emerald-600">Primary Hub</p>
                  </div>
                </CardContent>
              </Card>

              {/* Melbourne */}
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <MapPin className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-xl font-bold text-gray-900">Melbourne</h3>
                  </div>
                  <div className="space-y-2 text-gray-600">
                    <p>Level 8, 120 Collins Street</p>
                    <p>Melbourne VIC 3000</p>
                    <p className="font-semibold text-emerald-600">Victorian Operations</p>
                  </div>
                </CardContent>
              </Card>

              {/* Brisbane */}
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <MapPin className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-xl font-bold text-gray-900">Brisbane</h3>
                  </div>
                  <div className="space-y-2 text-gray-600">
                    <p>Level 12, 180 Queen Street</p>
                    <p>Brisbane QLD 4000</p>
                    <p className="font-semibold text-emerald-600">Queensland Operations</p>
                  </div>
                </CardContent>
              </Card>

              {/* Perth */}
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <MapPin className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-xl font-bold text-gray-900">Perth</h3>
                  </div>
                  <div className="space-y-2 text-gray-600">
                    <p>Level 6, 140 St Georges Terrace</p>
                    <p>Perth WA 6000</p>
                    <p className="font-semibold text-emerald-600">Western Australia Operations</p>
                  </div>
                </CardContent>
              </Card>

              {/* Adelaide */}
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <MapPin className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-xl font-bold text-gray-900">Adelaide</h3>
                  </div>
                  <div className="space-y-2 text-gray-600">
                    <p>Level 4, 85 King William Street</p>
                    <p>Adelaide SA 5000</p>
                    <p className="font-semibold text-emerald-600">South Australia Operations</p>
                  </div>
                </CardContent>
              </Card>

              {/* National Coverage */}
              <Card className="border-0 shadow-lg bg-emerald-50">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <MapPin className="h-6 w-6 text-emerald-600 mr-2" />
                    <h3 className="text-xl font-bold text-gray-900">National Coverage</h3>
                  </div>
                  <div className="space-y-2 text-gray-600">
                    <p>We also service:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Canberra, ACT</li>
                      <li>Darwin, NT</li>
                      <li>Hobart, TAS</li>
                      <li>Regional Centers</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TPG</span>
                </div>
                <span className="font-bold text-xl">The Partnership Group</span>
              </div>
              <p className="text-gray-400">
                Australia's premier recruitment partnership, connecting talent with opportunity across Healthcare or
                Construction.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/why-us" className="hover:text-white">
                    Why Us
                  </Link>
                </li>
                <li>
                  <Link href="/jobs" className="hover:text-white">
                    Current Jobs
                  </Link>
                </li>
                <li>
                  <Link href="/clients" className="hover:text-white">
                    For Clients
                  </Link>
                </li>
                <li>
                  <Link href="/candidates" className="hover:text-white">
                    For Candidates
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Industries</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Healthcare</li>
                <li>Construction</li>
                <li>Allied Health</li>
                <li>Project Management</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="text-gray-400 space-y-2">
                <p>1300 TPG JOBS</p>
                <p>info@partnershipgroup.com.au</p>
                <p>
                  Level 15, 1 Martin Place
                  <br />
                  Sydney NSW 2000
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} The Partnership Group. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
