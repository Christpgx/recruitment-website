import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DollarSign, MousePointer, TrendingUp, Target, Phone, Mail } from "lucide-react"

export default function GoogleCampaigns() {
  const campaignData = [
    {
      name: "Healthcare Recruitment - Sydney",
      type: "Search",
      status: "Active",
      budget: 150,
      spent: 127.45,
      clicks: 234,
      impressions: 12847,
      ctr: 1.82,
      cpc: 0.54,
      conversions: 12,
      conversionRate: 5.13,
      costPerConversion: 10.62,
    },
    {
      name: "Construction Jobs - Melbourne",
      type: "Search",
      status: "Active",
      budget: 200,
      spent: 189.23,
      clicks: 298,
      impressions: 15632,
      ctr: 1.91,
      cpc: 0.63,
      conversions: 18,
      conversionRate: 6.04,
      costPerConversion: 10.51,
    },
    {
      name: "Nursing Recruitment - National",
      type: "Display",
      status: "Active",
      budget: 100,
      spent: 78.9,
      clicks: 156,
      impressions: 23451,
      ctr: 0.67,
      cpc: 0.51,
      conversions: 8,
      conversionRate: 5.13,
      costPerConversion: 9.86,
    },
    {
      name: "Project Manager Jobs - Brisbane",
      type: "Search",
      status: "Paused",
      budget: 120,
      spent: 45.67,
      clicks: 89,
      impressions: 5432,
      ctr: 1.64,
      cpc: 0.51,
      conversions: 3,
      conversionRate: 3.37,
      costPerConversion: 15.22,
    },
  ]

  const keywordPerformance = [
    {
      keyword: "healthcare recruitment sydney",
      matchType: "Exact",
      clicks: 89,
      impressions: 1247,
      ctr: 7.14,
      cpc: 1.23,
      conversions: 5,
      quality_score: 8,
    },
    {
      keyword: "construction jobs melbourne",
      matchType: "Phrase",
      clicks: 156,
      impressions: 2341,
      ctr: 6.66,
      cpc: 0.89,
      conversions: 9,
      quality_score: 9,
    },
    {
      keyword: "nursing jobs australia",
      matchType: "Broad",
      clicks: 234,
      impressions: 4567,
      ctr: 5.12,
      cpc: 0.67,
      conversions: 12,
      quality_score: 7,
    },
    {
      keyword: "project manager recruitment",
      matchType: "Exact",
      clicks: 67,
      impressions: 987,
      ctr: 6.79,
      cpc: 1.45,
      conversions: 3,
      quality_score: 6,
    },
  ]

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Google Ads Campaign Management</h1>
          <p className="text-gray-600">Monitor and optimize your Google Ads performance</p>
        </div>

        {/* Campaign Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Spend</p>
                  <p className="text-2xl font-bold text-gray-900">$441.25</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-600" />
              </div>
              <div className="mt-2">
                <span className="text-sm text-gray-500">of $570 budget</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Clicks</p>
                  <p className="text-2xl font-bold text-gray-900">777</p>
                </div>
                <MousePointer className="h-8 w-8 text-blue-600" />
              </div>
              <div className="mt-2 flex items-center">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-sm text-green-600">+12.3% vs last week</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Conversions</p>
                  <p className="text-2xl font-bold text-gray-900">41</p>
                </div>
                <Target className="h-8 w-8 text-purple-600" />
              </div>
              <div className="mt-2">
                <span className="text-sm text-gray-500">5.28% conversion rate</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Cost/Conversion</p>
                  <p className="text-2xl font-bold text-gray-900">$10.76</p>
                </div>
                <DollarSign className="h-8 w-8 text-orange-600" />
              </div>
              <div className="mt-2 flex items-center">
                <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                <span className="text-sm text-green-600">-8.2% vs last week</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Campaign Performance Table */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Campaign Performance</CardTitle>
              <Button>Create New Campaign</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3">Campaign</th>
                    <th className="text-left p-3">Status</th>
                    <th className="text-left p-3">Budget</th>
                    <th className="text-left p-3">Spent</th>
                    <th className="text-left p-3">Clicks</th>
                    <th className="text-left p-3">CTR</th>
                    <th className="text-left p-3">CPC</th>
                    <th className="text-left p-3">Conversions</th>
                    <th className="text-left p-3">Conv. Rate</th>
                    <th className="text-left p-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {campaignData.map((campaign, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50">
                      <td className="p-3">
                        <div>
                          <p className="font-medium">{campaign.name}</p>
                          <Badge variant="outline" className="mt-1">
                            {campaign.type}
                          </Badge>
                        </div>
                      </td>
                      <td className="p-3">
                        <Badge variant={campaign.status === "Active" ? "default" : "secondary"}>
                          {campaign.status}
                        </Badge>
                      </td>
                      <td className="p-3">${campaign.budget}</td>
                      <td className="p-3">
                        <div>
                          <p>${campaign.spent}</p>
                          <p className="text-xs text-gray-500">
                            {((campaign.spent / campaign.budget) * 100).toFixed(0)}% used
                          </p>
                        </div>
                      </td>
                      <td className="p-3">{campaign.clicks}</td>
                      <td className="p-3">{campaign.ctr}%</td>
                      <td className="p-3">${campaign.cpc}</td>
                      <td className="p-3">{campaign.conversions}</td>
                      <td className="p-3">{campaign.conversionRate}%</td>
                      <td className="p-3">
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            Edit
                          </Button>
                          <Button size="sm" variant="outline">
                            View
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Keyword Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Top Performing Keywords</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {keywordPerformance.map((keyword, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-semibold">{keyword.keyword}</h4>
                        <Badge variant="outline" className="mt-1">
                          {keyword.matchType}
                        </Badge>
                      </div>
                      <Badge
                        variant={
                          keyword.quality_score >= 8
                            ? "default"
                            : keyword.quality_score >= 6
                              ? "secondary"
                              : "destructive"
                        }
                      >
                        QS: {keyword.quality_score}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">Clicks</p>
                        <p className="font-semibold">{keyword.clicks}</p>
                      </div>
                      <div>
                        <p className="text-gray-600">CTR</p>
                        <p className="font-semibold">{keyword.ctr}%</p>
                      </div>
                      <div>
                        <p className="text-gray-600">CPC</p>
                        <p className="font-semibold">${keyword.cpc}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Conversion Tracking */}
          <Card>
            <CardHeader>
              <CardTitle>Conversion Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                  <div className="flex items-center">
                    <Mail className="h-8 w-8 text-blue-600 mr-3" />
                    <div>
                      <h4 className="font-semibold">Contact Form Submissions</h4>
                      <p className="text-sm text-gray-600">Primary conversion goal</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold">28</p>
                    <p className="text-sm text-gray-600">68% of total</p>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                  <div className="flex items-center">
                    <Phone className="h-8 w-8 text-green-600 mr-3" />
                    <div>
                      <h4 className="font-semibold">Phone Calls</h4>
                      <p className="text-sm text-gray-600">Call tracking enabled</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold">13</p>
                    <p className="text-sm text-gray-600">32% of total</p>
                  </div>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-semibold mb-2">Conversion Value</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Total Value</p>
                      <p className="text-xl font-bold">$12,300</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">ROAS</p>
                      <p className="text-xl font-bold">2.79x</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle>Campaign Optimization Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-green-800">
                      Increase budget for "Construction Jobs - Melbourne"
                    </h4>
                    <p className="text-sm text-green-700">
                      High conversion rate (6.04%) and low cost per conversion. Consider increasing daily budget by 50%.
                    </p>
                  </div>
                  <Button size="sm" className="bg-green-600 hover:bg-green-700">
                    Apply
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-yellow-800">
                      Improve Quality Score for "project manager recruitment"
                    </h4>
                    <p className="text-sm text-yellow-700">
                      Quality Score of 6 is below average. Improve ad relevance and landing page experience.
                    </p>
                  </div>
                  <Button size="sm" className="bg-yellow-600 hover:bg-yellow-700">
                    Optimize
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-blue-800">Add negative keywords</h4>
                    <p className="text-sm text-blue-700">
                      Consider adding "free", "volunteer", "unpaid" as negative keywords to improve traffic quality.
                    </p>
                  </div>
                  <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                    Add Keywords
                  </Button>
                </div>
              </div>

              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-red-800">Review paused campaign</h4>
                    <p className="text-sm text-red-700">
                      "Project Manager Jobs - Brisbane" has been paused. High cost per conversion needs optimization.
                    </p>
                  </div>
                  <Button size="sm" className="bg-red-600 hover:bg-red-700">
                    Review
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
