import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { MapPin, Clock, DollarSign, Heart, HardHat, Search, Filter } from "lucide-react"

export default function JobsPage() {
  const jobs = [
    {
      id: 1,
      title: "Registered Nurse - ICU",
      company: "Sunshine Medical Centre",
      location: "Sydney, NSW",
      type: "Full-time",
      salary: "$75,000 - $85,000",
      category: "Healthcare",
      icon: Heart,
      posted: "2 days ago",
      description:
        "Experienced ICU nurse required for busy metropolitan hospital. Excellent benefits and professional development opportunities.",
    },
    {
      id: 2,
      title: "Construction Project Manager",
      company: "ABC Construction Company",
      location: "Melbourne, VIC",
      type: "Full-time",
      salary: "$120,000 - $140,000",
      category: "Construction",
      icon: HardHat,
      posted: "1 day ago",
      description:
        "Lead major commercial construction projects. Minimum 5 years experience required. Competitive package with vehicle allowance.",
    },
    {
      id: 3,
      title: "Physiotherapist",
      company: "Westside Health Group",
      location: "Brisbane, QLD",
      type: "Full-time",
      salary: "$70,000 - $80,000",
      category: "Healthcare",
      icon: Heart,
      posted: "3 days ago",
      description: "Join our growing allied health team. New graduates welcome with mentorship program available.",
    },
    {
      id: 4,
      title: "Site Supervisor",
      company: "Metro Building Solutions",
      location: "Perth, WA",
      type: "Full-time",
      salary: "$95,000 - $110,000",
      category: "Construction",
      icon: HardHat,
      posted: "1 week ago",
      description:
        "Supervise residential construction sites. Strong safety focus and team leadership skills essential.",
    },
    {
      id: 5,
      title: "Mental Health Nurse",
      company: "Northside Healthcare Network",
      location: "Adelaide, SA",
      type: "Part-time",
      salary: "$65,000 - $75,000",
      category: "Healthcare",
      icon: Heart,
      posted: "4 days ago",
      description:
        "Support mental health patients in community setting. Flexible hours and supportive team environment.",
    },
    {
      id: 6,
      title: "Electrical Supervisor",
      company: "Pacific Construction Services",
      location: "Darwin, NT",
      type: "Full-time",
      salary: "$110,000 - $130,000",
      category: "Construction",
      icon: HardHat,
      posted: "5 days ago",
      description: "Lead electrical teams on major infrastructure projects. FIFO arrangements available.",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="container mx-auto px-4 lg:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">TPG</span>
            </div>
            <span className="font-bold text-xl text-gray-900">The Partnership Group</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-emerald-600 font-medium">
              Home
            </Link>
            <Link href="/why-us" className="text-gray-700 hover:text-emerald-600 font-medium">
              Why Us
            </Link>
            <Link href="/jobs" className="text-emerald-600 font-medium">
              Jobs
            </Link>
            <Link href="/clients" className="text-gray-700 hover:text-emerald-600 font-medium">
              Clients
            </Link>
            <Link href="/candidates" className="text-gray-700 hover:text-emerald-600 font-medium">
              Candidates
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-emerald-600 font-medium">
              Contact
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Button variant="outline" className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50">
              <Link href="/register-job">Post a Job</Link>
            </Button>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Link href="/jobs">Find Jobs</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-to-br from-emerald-50 to-teal-50 py-16">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                Find Your Next <span className="text-emerald-600">Career Opportunity</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Discover exciting roles in Healthcare or Construction across Australia
              </p>

              {/* Search Bar */}
              <div className="bg-white rounded-lg shadow-lg p-6 max-w-4xl mx-auto">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input placeholder="Job title or keywords" className="pl-10" />
                  </div>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input placeholder="Location" className="pl-10" />
                  </div>
                  <Button className="bg-emerald-600 hover:bg-emerald-700">Search Jobs</Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Filters and Results */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4 lg:px-6">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Sidebar Filters */}
              <div className="lg:w-1/4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Filter className="h-5 w-5 mr-2" />
                      Filter Jobs
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h4 className="font-semibold mb-3">Industry</h4>
                      <div className="space-y-2">
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          Healthcare
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          Construction
                        </label>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-3">Job Type</h4>
                      <div className="space-y-2">
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          Full-time
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          Part-time
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          Contract
                        </label>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-3">Location</h4>
                      <div className="space-y-2">
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          NSW
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          VIC
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          QLD
                        </label>
                        <label className="flex items-center">
                          <input type="checkbox" className="mr-2" />
                          WA
                        </label>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Job Listings */}
              <div className="lg:w-3/4">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">{jobs.length} Jobs Found</h2>
                  <select className="border rounded-lg px-3 py-2">
                    <option>Sort by: Most Recent</option>
                    <option>Sort by: Salary High to Low</option>
                    <option>Sort by: Salary Low to High</option>
                  </select>
                </div>

                <div className="space-y-6">
                  {jobs.map((job) => {
                    const IconComponent = job.icon
                    return (
                      <Card key={job.id} className="hover:shadow-lg transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex items-start space-x-4">
                              <div
                                className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                                  job.category === "Healthcare" ? "bg-red-100" : "bg-orange-100"
                                }`}
                              >
                                <IconComponent
                                  className={`h-6 w-6 ${
                                    job.category === "Healthcare" ? "text-red-600" : "text-orange-600"
                                  }`}
                                />
                              </div>
                              <div className="flex-1">
                                <h3 className="text-xl font-bold text-gray-900 mb-1">{job.title}</h3>
                                <p className="text-gray-600 mb-2">{job.company}</p>
                                <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                                  <div className="flex items-center">
                                    <MapPin className="h-4 w-4 mr-1" />
                                    {job.location}
                                  </div>
                                  <div className="flex items-center">
                                    <Clock className="h-4 w-4 mr-1" />
                                    {job.type}
                                  </div>
                                  <div className="flex items-center">
                                    <DollarSign className="h-4 w-4 mr-1" />
                                    {job.salary}
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge
                                variant="outline"
                                className={
                                  job.category === "Healthcare"
                                    ? "border-red-200 text-red-700"
                                    : "border-orange-200 text-orange-700"
                                }
                              >
                                {job.category}
                              </Badge>
                              <p className="text-sm text-gray-500 mt-2">{job.posted}</p>
                            </div>
                          </div>
                          <p className="text-gray-600 mb-4">{job.description}</p>
                          <div className="flex justify-between items-center">
                            <Button
                              variant="outline"
                              className="bg-white text-emerald-600 border-emerald-600 hover:bg-emerald-50"
                            >
                              View Details
                            </Button>
                            <Button className="bg-emerald-600 hover:bg-emerald-700">Apply Now</Button>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>

                {/* Pagination */}
                <div className="flex justify-center mt-12">
                  <div className="flex space-x-2">
                    <Button variant="outline" className="bg-white text-gray-600 border-gray-300">
                      Previous
                    </Button>
                    <Button className="bg-emerald-600 hover:bg-emerald-700">1</Button>
                    <Button variant="outline" className="bg-white text-gray-600 border-gray-300">
                      2
                    </Button>
                    <Button variant="outline" className="bg-white text-gray-600 border-gray-300">
                      3
                    </Button>
                    <Button variant="outline" className="bg-white text-gray-600 border-gray-300">
                      Next
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-emerald-600">
          <div className="container mx-auto px-4 lg:px-6 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Don't See the Perfect Role?</h2>
            <p className="text-xl text-emerald-100 mb-8 max-w-2xl mx-auto">
              Register with us and we'll notify you when new opportunities that match your skills become available.
            </p>
            <Button
              size="lg"
              variant="outline"
              className="bg-white text-emerald-600 border-white hover:bg-emerald-50 text-lg px-8 py-3"
            >
              <Link href="/register-candidate">Register Your Interest</Link>
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 lg:px-6">
          <div className="grid lg:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">TPG</span>
                </div>
                <span className="font-bold text-xl">The Partnership Group</span>
              </div>
              <p className="text-gray-400">
                Australia's premier recruitment partnership, connecting talent with opportunity across Healthcare or
                Construction.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/why-us" className="hover:text-white">
                    Why Us
                  </Link>
                </li>
                <li>
                  <Link href="/jobs" className="hover:text-white">
                    Current Jobs
                  </Link>
                </li>
                <li>
                  <Link href="/clients" className="hover:text-white">
                    For Clients
                  </Link>
                </li>
                <li>
                  <Link href="/candidates" className="hover:text-white">
                    For Candidates
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Industries</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Healthcare</li>
                <li>Construction</li>
                <li>Allied Health</li>
                <li>Project Management</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <div className="text-gray-400 space-y-2">
                <p>1300 TPG JOBS</p>
                <p>info@partnershipgroup.com.au</p>
                <p>
                  Level 15, 1 Martin Place
                  <br />
                  Sydney NSW 2000
                </p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} The Partnership Group. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
